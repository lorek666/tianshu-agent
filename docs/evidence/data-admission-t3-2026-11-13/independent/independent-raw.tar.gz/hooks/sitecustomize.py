"""Review-only primitive faults and a post-acquisition stdin barrier.

Loaded solely in explicitly selected real ``python -m tianshu`` child processes.
No AdmissionRefused instances or business failure codes are manufactured here.
"""
from __future__ import annotations

import errno
import json
import os
from pathlib import Path
import sqlite3
import sys

mode = os.environ.get("T3_REVIEW_HOOK")
target = os.environ.get("T3_REVIEW_DB")
record_path = os.environ.get("T3_REVIEW_HOOK_RECORD")


def record(**value):
    with open(record_path, "a", encoding="utf-8") as stream:
        stream.write(json.dumps(value, ensure_ascii=False, sort_keys=True) + "\n")


if mode in ("state-initial", "state-completed"):
    original_replace = os.replace

    def replace(source, destination, *args, **kwargs):
        if str(Path(destination).absolute()) == target + ".migration.json":
            raw = json.loads(Path(source).read_bytes())
            expected = "completed" if mode == "state-completed" else "in_progress"
            if raw["status"] == expected:
                record(primitive="os.replace", mode=mode, status=raw["status"],
                       applied_steps=raw["applied_steps"], current_step=raw["current_step"])
                raise OSError(errno.EACCES, "review injected state publication failure")
        return original_replace(source, destination, *args, **kwargs)

    os.replace = replace
elif mode == "ddl":
    original_connect = sqlite3.connect

    def connect(*args, **kwargs):
        conn = original_connect(*args, **kwargs)
        actual = next(row[2] for row in conn.execute("PRAGMA database_list") if row[1] == "main")
        if actual and str(Path(actual).resolve()) == target:
            def authorize(action, first, second, database, origin):
                if action == sqlite3.SQLITE_CREATE_TABLE and first == "migration_log":
                    record(primitive="sqlite-authorizer", action="CREATE_TABLE", table=first)
                    return sqlite3.SQLITE_DENY
                return sqlite3.SQLITE_OK
            conn.set_authorizer(authorize)
        return conn

    sqlite3.connect = connect
elif mode in ("exclusive", "programmer"):
    import tianshu.migrate as migration

    if mode == "exclusive":
        original_acquire = migration.acquire_database_access

        def acquire(db, *, exclusive=False):
            access = original_acquire(db, exclusive=exclusive)
            if exclusive and str(Path(db).resolve()) == target:
                record(primitive="acquire_database_access", exclusive=True, pid=os.getpid())
                sys.stderr.write("T3_REVIEW_EXCLUSIVE_ACQUIRED\n")
                sys.stderr.flush()
                if sys.stdin.readline().strip() != "continue":
                    access.close()
                    raise RuntimeError("review barrier closed without continuation")
            return access

        migration.acquire_database_access = acquire
    else:
        def programming_error(*args, **kwargs):
            record(primitive="programming-error-boundary", exception="RuntimeError")
            raise RuntimeError("review programmer boundary sk-T3ReviewFakeCredential123456")
        migration.migrate = programming_error
