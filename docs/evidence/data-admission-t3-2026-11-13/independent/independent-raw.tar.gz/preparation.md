# T3 独立验收准备

日期：2026-11-13。状态：`PREPARATION_ONLY`。作者未交最终冻结；候选行为项一律为 `NOT_RUN_AWAIT_AUTHOR_FREEZE`。

本次只在 `/tmp/t3-admission-independent/` 准备独立矩阵、真实 CLI 子进程探针和执行门禁。没有读取作者正在开发的 T3，没有运行任何 T3 候选，没有改仓库、提交或推送。T2 的正式 `PASS_TASK2_CONTENT_ONLY` 原结论不重做、不扩张。

## 固定依据

`fixed-inputs.json` 绑定父 T3 授权书、已审契约、冻结计划 Task3、T2 正式独立报告与候选绑定，以及探针设计实际读取的固定 CLI/迁移/准入源文件。唯一固定产品来源是 `/tmp/t2-admission-independent/candidate-frozen/`，不是作者树。固定 Git 基线为 `585e3474b7f9f03bb118308470fac1f500c3a02e`。

父另明确要求：CLI 必须将原始 `Path` 交给 T2 `migrate`；不能先 `resolve()` 丢失根路径的 symlink 证据。已由 `T3-LAYOUT` 的真实 root symlink 用例覆盖。

## 独立探针范围

`acceptance-matrix.json` 中 12 项逐条给出验收断言、探针名称和边界。已准备 10 个测试函数，按参数设计共 35 个实例；这是静态设计计数，实际收集与运行数仍为 0。

1. 真实 `python -m tianshu data migrate` 解析、成功、六 code 的 JSON/文本路径、completed 重复调用。
2. 两种真实跨进程冲突均使用管道就绪信号和 stdin 屏障。独占屏障包裹原锁函数，只有取得真实独占句柄后才发送就绪；不以计时猜窗口。
3. 四个既有原名 failpoint 各精确验证 exit 77、实际机制版本、format2 严格字段与 before/after 位置、普通连接拒绝、锁释放、续做与再次调用；完整事件行、版本旁表、材料、顺序和 append-only 触发器均核对。
4. 原子发布在真实 `os.replace` 边界注入 `OSError`，分别覆盖首次进度与最终 completed 发布。DDL 使用 SQLite authorizer 真正拒绝 `CREATE TABLE migration_log`，经 SQLite 自身错误路径传播。不制造 `AdmissionRefused(code)` 冒充这六条路径。
5. 链接测试先通过原生 `symlink`/`os.link` 构造并证明链接事实，再要求 CLI 在创建进度前拒绝。仅原生构造不支持时 skip，原因保留异常类型、errno/winerror；当前无 Windows 设备或原生 CI 结论。
6. 单独的内部编程异常边界探针只测 CLI 分类与脱敏，不计入六条真实业务故障。用于输出的 token 形状是公开假值，不读取任何实际密钥。

六类错误正控均为独立新根与匹配备份的真实 CLI 成功；故障根只注入一项指定条件。`migration_incomplete` 用真实 SQLite DDL 构造形状合法的 v2 机制但不放进度；`backup_mismatch` 是备份后经真实 EventLog 追加；`maintenance_busy` 是另一个子进程持有真实 EventLog。它们不靠同一种异常替换。

## 执行门禁与交接后步骤

当前只允许 `python3 /tmp/t3-admission-independent/run_review.py` 进行 AST/编译/矩阵结构检查。该模式不导入或执行产品。正式 pytest 入口要求显式 `--execute`、独立冻结副本的绑定和新输出目录；禁止把作者树当执行源。

收到父最终冻结后，先亲读冻结 manifest 并按完整路径/SHA 重建候选；核对 T3 允许路径、继承 T1/T2 字节与其余基线无漂移。另生成 `candidate-binding.json`，至少包含：

```json
{
  "review_stage": "FROZEN_CANDIDATE",
  "source_path": "/tmp/t3-admission-independent/candidate-frozen",
  "author_handoff_path": "/tmp/t3-admission/handoff-manifest.json",
  "author_handoff_sha256": "<父最终冻结原件的真实SHA256>",
  "files": {"<每一候选文件相对路径>": "<真实SHA256>"}
}
```

此结构是未来接口说明，当前没有该绑定文件，也没有将占位值用于运行。正式命令形状为：

```sh
python3 /tmp/t3-admission-independent/run_review.py --execute \
  --binding /tmp/t3-admission-independent/candidate-binding.json \
  --python /path/to/verified-python3.12 \
  --output /tmp/t3-admission-independent/first-frozen-run
```

之后只按冻结 CLI 实际实现准备最少的接线变异：业务 code 被误改为通用失败，以及 CLI 提前 resolve 根路径。以已准备的六 code/真实 root symlink 探针验证；不再重复或扩大发明 T2 变异。

作者定向测试与文档对账仍须亲读其原件；作者自查结论不能替代上述独立执行。当前没有给出 T3 PASS，也没有运行 full、CI 或重复 T1/T2 回归。最终 full/原生 CI 由父在 T3 独立后统一安排。
