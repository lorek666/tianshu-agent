"""Two frozen Task3 CLI-only single-protection negative controls."""
from __future__ import annotations

import difflib
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
PYTHON = "/Users/ronfee/.codex/worktrees/g3-data-admission/天枢Agent/.venv/bin/python"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    original = json.loads((ROOT / "candidate-binding.json").read_text())
    source = Path(original["source_path"])
    variants = (
        ("MCLI1-code", '"code": exc.code,', '"code": "migration_failed",',
         "six_real_single_fault_paths and json-backup_mismatch"),
        ("MCLI2-raw-path", "run_migration(args.data_root, backup=args.backup)",
         "run_migration(args.data_root.resolve(), backup=args.backup)",
         "true_link_layout and root-symlink"),
    )
    results = []
    for name, before, after, selected in variants:
        variant = ROOT / "mutants" / name
        variant.parent.mkdir(exist_ok=True)
        existing = variant.exists()
        if not existing:
            shutil.copytree(source, variant)
        target = variant / "src/tianshu/data_cli.py"
        old = (source / "src/tianshu/data_cli.py").read_text()
        assert old.count(before) == 1
        new = old.replace(before, after)
        compile(new, str(target), "exec")
        if existing:
            assert target.read_text() == new
        else:
            target.write_text(new)
        diff = ROOT / (name + ".patch")
        diff.write_text("".join(difflib.unified_diff(old.splitlines(keepends=True), new.splitlines(keepends=True),
                        fromfile="frozen/src/tianshu/data_cli.py", tofile=name + "/src/tianshu/data_cli.py")))
        binding = dict(original)
        binding.update(source_path=str(variant), purpose="CLI_SINGLE_PROTECTION_MUTANT",
                       mutation_name=name, parent_binding_sha256=sha(ROOT / "candidate-binding.json"))
        binding["files"] = dict(original["files"])
        binding["files"]["src/tianshu/data_cli.py"] = sha(target)
        binding_path = ROOT / (name + "-binding.json")
        if binding_path.exists():
            assert json.loads(binding_path.read_text()) == binding
        else:
            binding_path.write_text(json.dumps(binding, ensure_ascii=False, indent=2) + "\n")
        output = ROOT / (name + "-run")
        cmd = [sys.executable, str(ROOT / "run_review.py"), "--execute", "--binding", str(binding_path),
               "--python", PYTHON, "--output", str(output), "-k", selected]
        if (output / "run.json").exists():
            returncode = json.loads((output / "run.json").read_text())["returncode"]
        else:
            run = subprocess.run(cmd, capture_output=True, text=True, timeout=90)
            (ROOT / (name + "-driver.stdout")).write_text(run.stdout)
            (ROOT / (name + "-driver.stderr")).write_text(run.stderr)
            returncode = run.returncode
        xml = ET.parse(output / "junit.xml").getroot()
        cases = list(xml.iter("testcase"))
        failures = [case for case in cases if case.find("failure") is not None]
        errors = [case for case in cases if case.find("error") is not None]
        assert returncode == 1 and len(cases) == len(failures) == 1 and not errors
        message = failures[0].find("failure").get("message", "")
        full_failure = failures[0].find("failure").text or ""
        if name == "MCLI1-code":
            assert "migration_failed" in message and "backup_mismatch" in message
        else:
            assert "0 == 2" in full_failure
        assert all(sha(source / rel) == expected for rel, expected in original["files"].items())
        results.append({
            "name": name, "classification": "KILLED_BY_REAL_CLI_BEHAVIOR",
            "selected": selected, "returncode": returncode, "executed": len(cases),
            "failures": len(failures), "errors": len(errors), "failure_message": message,
            "changed_path": "src/tianshu/data_cli.py", "before_sha256": original["files"]["src/tianshu/data_cli.py"],
            "after_sha256": sha(target), "binding_path": str(binding_path), "binding_sha256": sha(binding_path),
            "diff_path": str(diff), "diff_sha256": sha(diff),
            "run_path": str(output / "run.json"), "run_sha256": sha(output / "run.json"),
        })
    (ROOT / "cli-mutation-results.json").write_text(json.dumps(results, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps(results, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
