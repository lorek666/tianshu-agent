"""Static preparation check by default; explicit frozen binding gates future execution."""
from __future__ import annotations

import argparse
import ast
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def check_preparation():
    checked = []
    for path in sorted(ROOT.rglob("*.py")):
        source = path.read_text(encoding="utf-8")
        tree = ast.parse(source, filename=str(path))
        compile(tree, str(path), "exec")
        for node in ast.walk(tree):
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute):
                owner = node.func.value.id if isinstance(node.func.value, ast.Name) else None
                assert (owner, node.func.attr) not in (("time", "sleep"), ("test", "skip"))
                assert node.func.attr != "only"
        checked.append({"path": str(path.relative_to(ROOT)), "sha256": sha(path),
                        "syntax": "PASS_STATIC_ONLY"})
    matrix = json.loads((ROOT / "acceptance-matrix.json").read_text())
    assert all(item["status"] == "NOT_RUN_AWAIT_AUTHOR_FREEZE" for item in matrix["items"])
    tests = ast.parse((ROOT / "probes/test_t3_cli_independent.py").read_text())
    names = [node.name for node in tests.body if isinstance(node, ast.FunctionDef) and node.name.startswith("test_")]
    assert len(names) == 10
    constants = {}
    for node in tests.body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            try:
                constants[node.targets[0].id] = ast.literal_eval(node.value)
            except (ValueError, TypeError):
                pass
    cases = 0
    for node in tests.body:
        if not isinstance(node, ast.FunctionDef) or node.name not in names:
            continue
        count = 1
        for decorator in node.decorator_list:
            if isinstance(decorator, ast.Call) and isinstance(decorator.func, ast.Attribute) and decorator.func.attr == "parametrize":
                value = decorator.args[1]
                count *= len(constants[value.id] if isinstance(value, ast.Name) else ast.literal_eval(value))
        cases += count
    assert cases == matrix["designed_parameterized_cases"] == 35
    return {"stage": "PREPARATION_ONLY", "product_imports_executed": False,
            "candidate_tests_executed": 0, "designed_parameterized_cases": cases,
            "test_functions": names, "scripts": checked}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--binding", type=Path)
    parser.add_argument("--python", default=sys.executable)
    parser.add_argument("--output", type=Path)
    parser.add_argument("-k", dest="selected")
    args = parser.parse_args()
    if not args.execute:
        print(json.dumps(check_preparation(), ensure_ascii=False, indent=2))
        return 0
    if args.binding is None or args.output is None:
        parser.error("--execute requires --binding and a fresh --output directory")
    binding = json.loads(args.binding.read_text())
    if binding.get("review_stage") != "FROZEN_CANDIDATE":
        parser.error("binding is not a final frozen candidate")
    source = Path(binding["source_path"]).resolve()
    author = Path("/Users/ronfee/.codex/worktrees/g3-data-admission/天枢Agent")
    if source == author or author in source.parents:
        parser.error("execute against an independently reconstructed frozen copy, never the author tree")
    handoff = Path(binding["author_handoff_path"])
    if sha(handoff) != binding["author_handoff_sha256"]:
        parser.error("author handoff hash mismatch")
    actual_files = {str(p.relative_to(source)) for p in source.rglob("*") if p.is_file()}
    if actual_files != set(binding["files"]):
        parser.error("candidate file set differs from frozen binding")
    for rel, expected in binding["files"].items():
        if sha(source / rel) != expected:
            parser.error("candidate source hash mismatch: " + rel)
    args.output.mkdir(parents=True, exist_ok=False)
    env = {key: value for key, value in os.environ.items()
           if not (key.startswith(("TIANSHU_", "T3_REVIEW_")) or key.endswith(("BASE_URL", "API_KEY")))}
    env.update(T3_REVIEW_BINDING=str(args.binding.resolve()), T3_REVIEW_PYTHON=args.python,
               PYTHONDONTWRITEBYTECODE="1", PYTHONIOENCODING="utf-8")
    cmd = [args.python, "-m", "pytest", "-c", os.devnull, "-o", "addopts=", "-vv", "-rs",
           "-p", "no:cacheprovider", str(ROOT / "probes/test_t3_cli_independent.py"),
           "--basetemp", str(args.output / "cases"), "--junitxml", str(args.output / "junit.xml")]
    if args.selected:
        cmd += ["-k", args.selected]
    result = subprocess.run(cmd, cwd=source, env=env, capture_output=True, text=True,
                            encoding="utf-8", timeout=300)
    (args.output / "stdout.log").write_text(result.stdout, encoding="utf-8")
    (args.output / "stderr.log").write_text(result.stderr, encoding="utf-8")
    (args.output / "run.json").write_text(json.dumps({
        "argv": cmd, "returncode": result.returncode, "binding_sha256": sha(args.binding),
        "source_path": str(source), "stdout_sha256": sha(args.output / "stdout.log"),
        "stderr_sha256": sha(args.output / "stderr.log"),
        "source_unchanged": all(sha(source / rel) == expected for rel, expected in binding["files"].items()),
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    print(result.stdout)
    print(result.stderr, file=sys.stderr)
    return result.returncode


if __name__ == "__main__":
    raise SystemExit(main())
