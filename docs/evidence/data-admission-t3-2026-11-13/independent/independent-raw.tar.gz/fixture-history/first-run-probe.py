"""Independent Task3 CLI probes, guarded until a final frozen binding exists."""
from __future__ import annotations

from contextlib import closing
import hashlib
import json
import os
from pathlib import Path
import queue
import sqlite3
import subprocess
import sys
import threading

import pytest

HERE = Path(__file__).resolve().parent
SECRET = "sk-T3ReviewFakeCredential123456"
FAILURES = (
    "incompatible", "migration_incomplete", "progress_corrupt", "backup_mismatch",
    "maintenance_busy", "migration_failed",
)
FAILPOINTS = (
    ("migration-before-step-1", 0, [], 1, "before_step"),
    ("migration-after-step-1", 1, [], 1, "after_step"),
    ("migration-before-step-2", 1, [1], 2, "before_step"),
    ("migration-after-step-2", 2, [1], 2, "after_step"),
)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


class Context:
    def __init__(self, binding, output, python):
        assert binding["review_stage"] == "FROZEN_CANDIDATE"
        assert len(binding["author_handoff_sha256"]) == 64
        self.source = Path(binding["source_path"]).resolve()
        assert self.source != Path("/Users/ronfee/.codex/worktrees/g3-data-admission/天枢Agent")
        assert binding["files"], "empty source binding is not an authorization to execute"
        for rel, expected in binding["files"].items():
            assert digest(self.source / rel) == expected, rel
        self.output = output
        output.mkdir(parents=True, exist_ok=True)
        self.python = python
        self.index = 0
        self.children = []

    def env(self, root, hook=None, failpoint=None):
        env = {
            key: value for key, value in os.environ.items()
            if not (key.startswith(("TIANSHU_", "T3_REVIEW_"))
                    or key.endswith(("BASE_URL", "API_KEY")))
        }
        env.update(PYTHONPATH=str(self.source / "src"), PYTHONDONTWRITEBYTECODE="1",
                   TIANSHU_DATA_ROOT=str(root / "isolated-authority"),
                   PYTHONIOENCODING="utf-8")
        if failpoint:
            env["TIANSHU_FAILPOINT"] = failpoint
        if hook:
            env["PYTHONPATH"] = str(HERE.parent / "hooks") + os.pathsep + env["PYTHONPATH"]
            env.update(T3_REVIEW_HOOK=hook, T3_REVIEW_DB=str((root / "events.db").resolve()),
                       T3_REVIEW_HOOK_RECORD=str(root.parent / (hook + ".hook.jsonl")))
        return env

    def save(self, argv, result, prefix="run"):
        self.index += 1
        path = self.output / f"{self.index:03d}-{prefix}"
        path.with_suffix(".stdout").write_text(result.stdout or "", encoding="utf-8")
        path.with_suffix(".stderr").write_text(result.stderr or "", encoding="utf-8")
        path.with_suffix(".json").write_text(json.dumps({
            "argv": argv, "returncode": result.returncode,
            "stdout_sha256": digest(path.with_suffix(".stdout")),
            "stderr_sha256": digest(path.with_suffix(".stderr")),
        }, ensure_ascii=False, indent=2), encoding="utf-8")

    def run(self, argv, root, *, hook=None, failpoint=None):
        result = subprocess.run(argv, cwd=root.parent, env=self.env(root, hook, failpoint),
                                capture_output=True, text=True, encoding="utf-8", timeout=30)
        self.save(argv, result)
        return result

    def cli(self, root, backup, *, as_json=True, hook=None, failpoint=None):
        argv = [self.python, "-m", "tianshu", "data", "migrate", "--data-root", str(root),
                "--backup", str(backup)]
        if as_json:
            argv.append("--json")
        return self.run(argv, root, hook=hook, failpoint=failpoint)

    def child(self, action, root, other=None):
        argv = [self.python, str(HERE / "child.py"), action, str(root)]
        if other is not None:
            argv.append(str(other))
        return self.run(argv, root)

    def fixture(self, parent, *, backup_name="backup"):
        parent.mkdir(parents=True)
        root, backup = parent / "root", parent / backup_name
        assert self.child("seed", root).returncode == 0
        assert self.child("backup", root, backup).returncode == 0
        assert len(snapshot(root)["events"]) == 3
        return root, backup

    def start(self, argv, root, *, hook=None):
        proc = subprocess.Popen(argv, cwd=root.parent, env=self.env(root, hook),
                                stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                text=True, encoding="utf-8", bufsize=1)
        self.children.append(proc)
        return proc

    def finish(self, proc, *, input_text=None, prefix="barrier", consumed_stdout="", consumed_stderr=""):
        try:
            stdout, stderr = proc.communicate(input_text, timeout=20)
        except subprocess.TimeoutExpired:
            proc.kill()
            stdout, stderr = proc.communicate(timeout=5)
            self.save(proc.args, subprocess.CompletedProcess(proc.args, proc.returncode,
                      consumed_stdout + stdout, consumed_stderr + stderr), prefix)
            raise
        result = subprocess.CompletedProcess(proc.args, proc.returncode,
                    consumed_stdout + stdout, consumed_stderr + stderr)
        self.save(proc.args, result, prefix)
        return result


@pytest.fixture
def ctx(tmp_path):
    binding_path = os.environ.get("T3_REVIEW_BINDING")
    if not binding_path:
        pytest.fail("not authorized: final frozen-candidate binding is required")
    context = Context(json.loads(Path(binding_path).read_text()), tmp_path / "raw",
                      os.environ.get("T3_REVIEW_PYTHON", sys.executable))
    try:
        yield context
    finally:
        # Even a malformed/absent ready marker must not strand a real child.
        for proc in context.children:
            if proc.poll() is None:
                proc.kill()
                context.finish(proc, prefix="forced-cleanup")


def snapshot(root):
    with closing(sqlite3.connect((root / "events.db").resolve().as_uri() + "?mode=ro", uri=True)) as conn:
        return {
            "version": conn.execute("PRAGMA user_version").fetchone()[0],
            "events": [tuple(row) for row in conn.execute("SELECT * FROM events ORDER BY seq")],
            "event_versions": [tuple(row) for row in conn.execute("SELECT * FROM event_versions ORDER BY seq")],
            "triggers": [tuple(row) for row in conn.execute(
                "SELECT name,sql FROM sqlite_schema WHERE type='trigger' AND tbl_name='events' ORDER BY name")],
            "blobs": {str(p.relative_to(root)): digest(p) for p in sorted((root / "blobs").rglob("*")) if p.is_file()},
        }


def tree(root):
    return {str(p.relative_to(root)): [digest(p), p.stat().st_mtime_ns]
            for p in sorted(root.rglob("*")) if p.is_file()}


def state(root):
    path = root / "events.db.migration.json"
    return json.loads(path.read_bytes()) if path.is_file() else None


def success(result):
    assert result.returncode == 0, (result.stdout, result.stderr)
    report = json.loads(result.stdout)
    assert report["operation"] == "migrate" and report["ok"] is True
    assert "code" in report
    return report


def refusal(result, code, as_json=True):
    assert result.returncode == 2, (result.returncode, result.stdout, result.stderr)
    if as_json:
        report = json.loads(result.stdout)
        assert report["operation"] == "migrate" and report["ok"] is False
        assert report["code"] == code
    else:
        assert code in result.stdout + result.stderr
    assert SECRET not in result.stdout + result.stderr


def barrier_line(stream):
    result = queue.Queue()
    thread = threading.Thread(target=lambda: result.put(stream.readline()), daemon=True)
    thread.start()
    line = result.get(timeout=15)
    thread.join(timeout=1)
    assert not thread.is_alive()
    assert line, "child exited before reaching its barrier"
    return line


def hook_records(root, mode):
    return [json.loads(line) for line in (root.parent / (mode + ".hook.jsonl")).read_text().splitlines()]


def assert_events_unchanged(before, root):
    after = snapshot(root)
    for key in ("events", "event_versions", "triggers", "blobs"):
        assert after[key] == before[key], key


def assert_append_only(root):
    with closing(sqlite3.connect(root / "events.db")) as conn:
        for statement in ("UPDATE events SET actor_id='changed' WHERE seq=1", "DELETE FROM events WHERE seq=1"):
            with pytest.raises(sqlite3.IntegrityError, match="append-only"):
                conn.execute(statement)
            conn.rollback()


@pytest.mark.parametrize("args", [
    ["migrate"], ["migrate", "--data-root", "missing"], ["migrate", "--backup", "missing"],
    ["migrate", "--data-root", "missing", "--dest", "other"],
    ["restore", "--data-root", "missing", "--approve"], ["apply", "--data-root", "missing"],
    ["restore-plan", "missing", "--data-root", "other", "--apply"],
])
def test_required_arguments_and_absent_apply_are_parser_exit2(ctx, tmp_path, args):
    parent = tmp_path / "parser"
    parent.mkdir()
    result = ctx.run([ctx.python, "-m", "tianshu", "data", *args], parent / "missing")
    assert result.returncode == 2 and "usage:" in result.stderr
    assert list(parent.iterdir()) == []


def test_success_and_completed_noop_preserve_events_backup_and_service_state(ctx, tmp_path):
    root, backup = ctx.fixture(tmp_path / "success")
    before, saved = snapshot(root), tree(backup)
    success(ctx.cli(root, backup))
    assert state(root)["status"] == "completed" and snapshot(root)["version"] == 2
    completed = tree(root)
    success(ctx.cli(root, backup))
    assert tree(root) == completed and tree(backup) == saved
    assert_events_unchanged(before, root)
    assert_append_only(root)
    assert not (root / "run").exists()
    assert not (root / "isolated-authority").exists()


@pytest.mark.parametrize("code", FAILURES)
@pytest.mark.parametrize("as_json", [True, False], ids=["json", "text"])
def test_six_real_single_fault_paths_and_positive_controls(ctx, tmp_path, code, as_json):
    normal, saved = ctx.fixture(tmp_path / "positive")
    success(ctx.cli(normal, saved))
    root, backup = ctx.fixture(tmp_path / "negative")
    hook = None
    proc = None
    consumed = ""
    if code == "incompatible":
        with closing(sqlite3.connect(root / "events.db")) as conn:
            conn.execute("PRAGMA user_version=999")
    elif code == "migration_incomplete":
        with closing(sqlite3.connect(root / "events.db")) as conn:
            conn.executescript("CREATE TABLE migration_log(step INTEGER PRIMARY KEY, applied_at INTEGER NOT NULL, "
                               "note TEXT NOT NULL DEFAULT ''); CREATE INDEX idx_migration_log_applied "
                               "ON migration_log(applied_at); INSERT INTO migration_log VALUES(1,1,''); "
                               "INSERT INTO migration_log VALUES(2,2,''); PRAGMA user_version=2;")
        assert snapshot(root)["version"] == 2 and state(root) is None
    elif code == "progress_corrupt":
        (root / "events.db.migration.json").write_bytes(b"{")
    elif code == "backup_mismatch":
        assert ctx.child("append", root).returncode == 0
        assert len(snapshot(root)["events"]) == 4
    elif code == "migration_failed":
        hook = "state-initial"
    else:
        argv = [ctx.python, str(HERE / "child.py"), "hold", str(root)]
        proc = ctx.start(argv, root)
        consumed = barrier_line(proc.stdout)
        held = json.loads(consumed)
        assert held["kind"] == "held" and held["pid"] != os.getpid()
    before = snapshot(root)
    try:
        refusal(ctx.cli(root, backup, as_json=as_json, hook=hook), code, as_json)
        assert_events_unchanged(before, root)
        if code == "progress_corrupt":
            assert (root / "events.db.migration.json").read_bytes() == b"{"
        else:
            assert (state(root) or {}).get("status") != "completed"
        if hook:
            assert hook_records(root, hook)[0]["primitive"] == "os.replace"
    finally:
        if proc is not None:
            held_result = ctx.finish(proc, input_text="close\n", consumed_stdout=consumed)
            assert held_result.returncode == 0
    assert ctx.child("lock", root).returncode == 0


def test_shared_eventlog_child_refuses_cli_and_original_connection_still_appends(ctx, tmp_path):
    root, backup = ctx.fixture(tmp_path / "shared")
    before = snapshot(root)
    proc = ctx.start([ctx.python, str(HERE / "child.py"), "hold", str(root)], root)
    consumed = barrier_line(proc.stdout)
    assert json.loads(consumed)["pid"] != os.getpid()
    try:
        refusal(ctx.cli(root, backup), "maintenance_busy")
        assert state(root) is None
        proc.stdin.write("append\n")
        proc.stdin.flush()
        appended = barrier_line(proc.stdout)
        consumed += appended
        assert json.loads(appended)["kind"] == "appended"
        after = snapshot(root)["events"]
        assert after[:-1] == before["events"] and len(after) == len(before["events"]) + 1
    finally:
        result = ctx.finish(proc, input_text="close\n", consumed_stdout=consumed)
        assert result.returncode == 0
    assert ctx.child("lock", root).returncode == 0
    fresh = root.parent / "fresh-backup"
    assert ctx.child("backup", root, fresh).returncode == 0
    success(ctx.cli(root, fresh))


def test_real_cli_exclusive_acquisition_refuses_another_process_before_payload_creation(ctx, tmp_path):
    root, backup = ctx.fixture(tmp_path / "exclusive")
    argv = [ctx.python, "-m", "tianshu", "data", "migrate", "--data-root", str(root),
            "--backup", str(backup), "--json"]
    proc = ctx.start(argv, root, hook="exclusive")
    consumed = barrier_line(proc.stderr)
    assert consumed == "T3_REVIEW_EXCLUSIVE_ACQUIRED\n"
    assert hook_records(root, "exclusive")[0]["exclusive"] is True
    payload = root / "must-not-create-payload"
    try:
        result = ctx.child("open", root, payload)
        assert result.returncode == 23
        report = json.loads(result.stdout)
        assert report["exception"] == "MaintenanceBusy" and report["payload_exists"] is False
        assert not payload.exists() and state(root) is None
    finally:
        result = ctx.finish(proc, input_text="continue\n", consumed_stderr=consumed)
    success(result)
    assert ctx.child("open", root, payload).returncode == 0 and payload.is_dir()


@pytest.mark.parametrize("point,version,applied,current,position", FAILPOINTS)
def test_four_true_cli_77_windows_and_resume_idempotence(ctx, tmp_path, point, version, applied, current, position):
    root, backup = ctx.fixture(tmp_path / point)
    before, saved = snapshot(root), tree(backup)
    result = ctx.cli(root, backup, failpoint=point)
    assert result.returncode == 77 and "[failpoint] " + point in result.stderr
    raw = state(root)
    assert set(raw) == {"format", "format_version", "db_path", "from_version", "target_version", "status",
                        "applied_steps", "current_step", "plan_sha256", "backup", "baseline",
                        "started_at_ms", "updated_at_ms"}
    assert raw["format"] == "tianshu-migration" and type(raw["format_version"]) is int
    assert raw["format_version"] == 2 and raw["from_version"] == 0 and raw["target_version"] == 2
    assert raw["db_path"] == str((root / "events.db").resolve())
    assert raw["status"] == "in_progress" and raw["applied_steps"] == applied and raw["current_step"] == current
    assert set(raw["backup"]) == {"path", "manifest_sha256"}
    assert set(raw["baseline"]) == {"sqlite_algorithm", "sqlite_sha256", "material_algorithm", "material_sha256"}
    assert raw["backup"]["path"] == str(backup.resolve())
    assert raw["backup"]["manifest_sha256"] == digest(backup / "backup.json")
    assert snapshot(root)["version"] == version
    done = applied[-1] if applied else raw["from_version"]
    assert position == ("before_step" if version == done else "after_step")
    assert not (root / "migration.json").exists()
    payload = root / "blocked-payload"
    blocked = ctx.child("open", root, payload)
    assert blocked.returncode == 23 and json.loads(blocked.stdout)["code"] == "migration_incomplete"
    assert not payload.exists()
    assert ctx.child("lock", root).returncode == 0
    assert_events_unchanged(before, root)
    success(ctx.cli(root, backup))
    assert state(root)["status"] == "completed" and snapshot(root)["version"] == 2
    completed = tree(root)
    success(ctx.cli(root, backup))
    assert tree(root) == completed and tree(backup) == saved
    assert_events_unchanged(before, root)
    assert_append_only(root)


@pytest.mark.parametrize("mode,version", [("state-initial", 0), ("state-completed", 2), ("ddl", 0)])
def test_primitive_publication_and_ddl_failure_never_complete_and_release_resources(ctx, tmp_path, mode, version):
    root, backup = ctx.fixture(tmp_path / mode)
    before = snapshot(root)
    refusal(ctx.cli(root, backup, hook=mode), "migration_failed")
    records = hook_records(root, mode)
    assert records and records[0]["primitive"] == ("sqlite-authorizer" if mode == "ddl" else "os.replace")
    assert (state(root) or {}).get("status") != "completed"
    assert snapshot(root)["version"] == version
    assert_events_unchanged(before, root)
    assert ctx.child("lock", root).returncode == 0
    success(ctx.cli(root, backup))
    assert_events_unchanged(before, root)


@pytest.mark.parametrize("layout", ["root-symlink", "db-symlink", "db-hardlink"])
def test_true_link_layout_is_refused_before_progress_and_preserves_raw_root_evidence(ctx, tmp_path, layout):
    root, backup = ctx.fixture(tmp_path / layout)
    before = snapshot(root)
    supplied = root
    try:
        if layout == "root-symlink":
            supplied = root.parent / "raw-root-link"
            supplied.symlink_to(root, target_is_directory=True)
            assert supplied.is_symlink() and supplied.resolve() == root.resolve()
        elif layout == "db-symlink":
            actual = root.parent / "actual-events.db"
            (root / "events.db").rename(actual)
            (root / "events.db").symlink_to(actual)
            assert (root / "events.db").is_symlink()
        else:
            alias = root.parent / "events-hardlink.db"
            os.link(root / "events.db", alias)
            assert alias.stat().st_ino == (root / "events.db").stat().st_ino
            assert (root / "events.db").stat().st_nlink == 2
    except (OSError, NotImplementedError) as exc:
        pytest.skip(f"native {layout} construction unavailable: {type(exc).__name__}; errno={getattr(exc, 'errno', None)}; winerror={getattr(exc, 'winerror', None)}")
    refusal(ctx.cli(supplied, backup), "incompatible")
    assert state(root) is None and not (root / "migration.json").exists()
    assert_events_unchanged(before, root)


@pytest.mark.parametrize("as_json", [True, False], ids=["json", "text"])
def test_success_and_actual_corrupt_progress_path_are_redacted(ctx, tmp_path, as_json):
    root, backup = ctx.fixture(tmp_path / "success-redact", backup_name=SECRET)
    result = ctx.cli(root, backup, as_json=as_json)
    assert result.returncode == 0 and SECRET not in result.stdout + result.stderr
    assert "***" in result.stdout + result.stderr
    if as_json:
        success(result)
    root, backup = ctx.fixture(tmp_path / SECRET)
    # Rename a real root so the true corrupt-sidecar exception includes a token-shaped path.
    secret_root = root.with_name(SECRET)
    root.rename(secret_root)
    (secret_root / "events.db.migration.json").write_bytes(b"{")
    refusal(ctx.cli(secret_root, backup, as_json=as_json), "progress_corrupt", as_json)


def test_programming_exception_is_not_relabelled_as_six_business_codes(ctx, tmp_path):
    root, backup = ctx.fixture(tmp_path / "programmer")
    result = ctx.cli(root, backup, hook="programmer")
    assert hook_records(root, "programmer")[0]["exception"] == "RuntimeError"
    assert result.returncode == 2 and SECRET not in result.stdout + result.stderr
    assert "review programmer boundary" in result.stdout + result.stderr
    try:
        report = json.loads(result.stdout)
    except json.JSONDecodeError:
        report = None
    assert not (isinstance(report, dict) and report.get("operation") == "migrate"
                and report.get("code") in FAILURES)
    assert state(root) is None and ctx.child("lock", root).returncode == 0
