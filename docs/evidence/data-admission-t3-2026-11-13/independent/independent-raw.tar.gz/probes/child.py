"""Frozen-candidate subprocess fixtures; never imported by preparation checks."""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import sys


def emit(**value):
    print(json.dumps(value, ensure_ascii=False, sort_keys=True), flush=True)


def append(log, label):
    return log.append(
        "independent-review", "run.start",
        {"task": label, "workspace": "fixture", "out": "review.txt", "limits": {}, "tools": []},
        actor_kind="core", legacy_write=True,
    )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=("seed", "backup", "append", "hold", "open", "lock"))
    parser.add_argument("root", type=Path)
    parser.add_argument("other", type=Path, nargs="?")
    args = parser.parse_args()
    if args.action == "lock":
        from tianshu.maintenance import acquire_database_access
        with acquire_database_access(args.root / "events.db", exclusive=True):
            emit(kind="exclusive-acquired", pid=os.getpid())
        return 0
    if args.action == "backup":
        from tianshu.backup import create_backup
        manifest = create_backup(args.root, args.other)
        emit(kind="backup-created", event_count=manifest.event_count)
        return 0
    from tianshu.events import EventLog
    if args.action == "open":
        from tianshu.credentials import redact
        try:
            log = EventLog(args.root / "events.db", blob_dir=args.other)
        except Exception as exc:
            emit(kind="refused", exception=type(exc).__name__, code=getattr(exc, "code", None),
                 message=redact(str(exc)), payload_exists=args.other.exists())
            return 23
        log.close()
        emit(kind="opened", payload_exists=args.other.exists())
        return 0
    log = EventLog(args.root / "events.db", blob_dir=args.root / "blobs")
    try:
        if args.action == "seed":
            first = append(log, "first-中文")
            second = log.append(
                "independent-review", "tool.intent",
                {"call_id": "independent-call", "tool_id": "read_text",
                 "args": {"content": "payload-中文" * 40_000}, "args_hash": "a" * 64},
                actor_kind="core", legacy_write=True,
            )
            third = append(log, "third")
            emit(kind="seeded", seqs=[first, second, third])
        elif args.action == "append":
            emit(kind="appended", seq=append(log, "after-backup"))
        else:
            emit(kind="held", pid=os.getpid())
            for command in sys.stdin:
                if command.strip() == "append":
                    emit(kind="appended", seq=append(log, "original-holder-still-writable"))
                elif command.strip() == "close":
                    break
                else:
                    raise RuntimeError("unexpected barrier command")
    finally:
        log.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
