# Task2 独立验收预备记录

状态：`READY_TO_WAIT_FOR_AUTHOR_FREEZE`。仅有固定585的预置事实自核；**T2候选与12个变异均未验收，不签发通过结论**。不改作者树、不commit、不跑full/CI，不实施或授权Task3。

## 固定权威输入

- 正式基线：`585e3474b7f9f03bb118308470fac1f500c3a02e`，独立 `git archive` 副本为 `source-585/`。
- 契约正文 SHA256：`c62dba28c2e4b4c2d17ce100da233ea26c71f8dcea5f4c0611608fbabf2f8584`（`c62d`是此摘要前缀，不是Git提交）。
- 已审计划 SHA256：`464849b2ea0f6e5a0dde4b00b4aed00b72d1e51c9af9bdda4d7d38d7eafde875`，只消费§1.4、§2和Task2；不重开设计。
- `fixed-inputs.json` 固定264项非docs加上述契约/计划共266项字节、草案hash、T1正式绑定原件与合成输入。`fixed-fixture-index.json` 索引本次真实生成的合成材料。

## 预置事实已自核

使用真实 `EventLog`、`build_stack`、离线 `HashEmbeddingProvider`、`memory_control.remember`、`create_backup/verify_backup`、T1严格state/inspect，以及585注册的两步机制事务；未调用未来T2协议。

1. 真实stack建出35张持久表，含FTS全部shadow、向量、游标、summary与预算账本；六次正式控制面记忆写入得到6条记忆和6条向量。另建未知扩展表，NULL/TEXT/INTEGER/REAL/BLOB真实存储类型不同。
2. 未checkpoint的已提交事务使main原始文件字节保持不变，但WAL存在；真实备份包含新行，保存库与活连接内容一致。故可以证明只hash主文件的危险，不靠setup/import红。
3. 三目录各添一个未引用材料后事件不变，原备份仍verify通过；独立inventory看到全部额外路径，包括`.tmp`。保存备份的未声明文件则被既有verify_backup直接拒绝：该路径只证明上游守卫，不算T2 inventory变异证据。
4. 只改真实memories投影行，事件相同、业务fingerprint不同；还原fixture后恢复原fingerprint。
5. 真实FTS optimize令segments从6变1。虚拟行、MemoryProjection.projection_hash和事件相同；memory_fts_data与memory_fts_idx持久行确变，integrity_check=ok。未直接写shadow。
6. 只改manifest合法created_at_ms即可改变原字节SHA而仍verify通过，DB/材料字节不变。
7. 585真实注册步骤构造v0/v1/v2；业务观察fingerprint相同，旧step1 typed值从v1保留至v2。三个保存v2变体分别只改applied_at、note或等效显式ASC索引定义，verify与inspect均通过、step=[1,2]且business相同，完整机制事实却不同。
8. T1共享state可严格roundtrip；已登记current的一步提交窗口合法，两种未登记/跨两步窗口拒绝。这个纯parser对象未落盘，其计划文档hash不冒充未来产品计划digest。

草案中的fingerprint仅作独立预置事实观察器，**不是产品 `tianshu-sqlite-logical-v1` 的替代实现或候选许可**。固定585缺少data_digest，旧migrate仍为format1协调器；这被明确记作API未就绪，未计行为RED。两个草案作者错误（sorted语法、预想表名与真实表名不同）已纠正，仅作为草案调试记录，不计产品红。

## 具名变异验收矩阵

机器版见 `acceptance-matrix.json`。全部条目当前为 `NOT_RUN_AWAIT_AUTHOR_FREEZE`。

### M01 · `omit-extra-live-material`

- 入口/证据：Task2 material_inventory / bidirectional inventory guard；计划测试 `test_live_extra_and_saved_undeclared_material_refused`。
- 先证构造：真实 v0 同根备份通过 verify；之后只在 artifacts/.tmp、根 blobs、memory_blobs 添未引用文件；事件与 DB 内容未变。
- 隔离变异：只遍历 manifest 已声明项，移除活根额外文件检查。
- 必红断言：migrate 必须以备份不匹配拒绝；无 progress/DDL/材料改动。
- 准备状态：585 已证明三目录额外材料且原备份仍 verify 通过。保存备份多文件已由 verify_backup 首先拒绝；该支不用于声称杀死 T2 inventory 变异。

### M02 · `events-only-business-digest`

- 入口/证据：Task2 sqlite_digest / all persistent objects；计划测试 `test_binding_includes_every_persistent_table_and_schema_object; test_projection_only_change_refused; test_typed_rows_distinguish_null_text_integer_float_blob`。
- 先证构造：真实 stack/FTS/vector/游标/summary/账本已建；分别改真实投影行、未知扩展表 typed 值、业务 index/trigger/view，证明事件行完全相同而对应业务对象变化。
- 隔离变异：用只 hash events 的实现替代完整业务摘要，不能把缺模块或 SQL setup 错误当红。
- 必红断言：每个独立业务/结构变化拒绝旧备份；纯重排无语义变化正控保持可比。
- 准备状态：585 真实控制面写入形成 35 张表；投影-only 与未知 typed 表事实已验证。空表对象的候选参数化需冻结后逐目标核实存在。

### M03 · `omit-manifest-byte-binding`

- 入口/证据：Task2 resume and completed A binding；计划测试 `test_manifest_or_plan_replacement_refuses_resume`。
- 先证构造：候选真实库级 child 在 before-step-1 硬退 77，读取其真实 format2 progress；只改 backup.json 的合法 created_at_ms，verify 仍通过且 DB/材料字节未变。
- 隔离变异：移除绑定原始 manifest SHA256 的比较；不移除 verify。
- 必红断言：resume 和原绑定完成重复都须拒绝；版本/事件/progress 不变。
- 准备状态：585 已证明合法 manifest 字节变化仍 verify 通过；真实 T2 progress 等作者 freeze 后生成。

### M04 · `omit-plan-binding`

- 入口/证据：Task2 plan SHA / algorithms / exclusion objects；计划测试 `test_manifest_or_plan_replacement_refuses_resume`。
- 先证构造：从真实 T2 故障进度出发，修改仍为合法 64hex 的 plan_sha256，或在隔离副本改变注册步骤 description/SQL；不得用坏 JSON 或非法字段作唯一负例。
- 隔离变异：移除当前计划/算法/排除对象与冻结 state 的绑定校验。
- 必红断言：拒绝续做且不执行下一步；正控原计划可以续做。
- 准备状态：585 严格共享类型可 roundtrip；未来产品 plan digest 尚不存在，不用文档计划 SHA 冒充它。

### M05 · `ignore-real-backup-version`

- 入口/证据：Task2 initial/resume/B real-version equations；计划测试 `test_initial_binding_requires_real_version_and_full_mechanism_equality; test_resume_keeps_original_version_backup_as_valid_baseline`。
- 先证构造：保存库通过真实注册步骤成为合法 v1/v2，并同步合法 manifest 的版本与 DB 文件 hash，使 verify 通过；事件、业务、材料相同。首次要求 live initial=backup real；续做要求 backup real=state.from。
- 隔离变异：只信 manifest 或删除真实 backup version 等式；不能把正常 live 前进误要求 backup version=current live。
- 必红断言：不匹配真实版本拒绝；from0 backup 在合法 live1/live2 续做必须成功。
- 准备状态：585 已构造并核对 v0/v1/v2 合法保存点，业务 fingerprint 相同；真实 T2 续做正控待 freeze。

### M06 · `ignore-origin-mechanism`

- 入口/证据：Task2 initial full mechanism equality；计划测试 `test_initial_binding_requires_real_version_and_full_mechanism_equality`。
- 先证构造：从实际 live v1 与同根保存 v1 起步；只改保存的 step1 applied_at，保持类型/shape/step/version 合法并更新 manifest，verify 和 inspect 都必须成功。
- 隔离变异：首次仅比较业务/材料和版本，遗漏完整起点 mechanism snapshot。
- 必红断言：首次新绑定拒绝同 version 不同完整 audit/definition；无进度或 DDL。
- 准备状态：585 已证明 audit-only 合法保存变体可通过 verify/inspect；候选 v1 初始入口待冻结。

### M07 · `ignore-inherited-audit`

- 入口/证据：Task2 reachable mechanism delta from original version；计划测试 `test_resume_rejects_unplanned_inherited_audit_change`。
- 先证构造：候选从真实 v1 backup 开始，在 step2 提交后硬退；保留真实合法 state，单独改 live 已继承 step1 的 applied_at/note 或额外 audit；业务、version、已提交 steps 仍相同。
- 隔离变异：把旧 audit 行/值变化也当作允许新步骤时间差，不验证从保存起点继承内容。
- 必红断言：拒绝续做且不将 state 修为 completed；无改动正控按同原 v1 backup 成功。
- 准备状态：585 注册步骤的原 step1 typed 值在 v1→v2 确实保留；真正 T2 crash state 与变异点待冻结。

### M08 · `omit-fts-shadow-content`

- 入口/证据：Task2 sqlite_digest FTS persistent shadow tables；计划测试 `test_fts_optimize_same_virtual_rows_changed_shadow_refuses_stale_backup`。
- 先证构造：真实 build_stack + 六次 memory_control.remember；备份后执行真正 FTS optimize；先断言 virtual rows、memory projection、events 不变且 shadow rows 变化、integrity_check=ok。
- 隔离变异：枚举表时排除 FTS shadow，仅保留虚拟行/记忆投影。
- 必红断言：旧保存点必须拒绝；原候选基线必须能接收 optimize 前同一点备份。
- 准备状态：585 实证 6 segments→1；memory_fts_data/idx 变化，其余声称不变的事实均亲核。绝不直接篡改 shadow 代替 optimize。

### M09 · `legacy-number-union`

- 入口/证据：Task2 coordinator progress reachability, retaining T1 strict shape；计划测试 `test_resume_accepts_only_current_step_commit_window`。
- 先证构造：使用字段形状本身合法的 format2：done=()/current=None 但 actual1；或 done=()/current1 但 actual2。配对合法 before/after-current 窗口和 from1 正控。
- 隔离变异：将协调器可达性判断恢复成 sorted(set(state steps) ∪ versions<=actual)，据 DB 数字补造步骤。
- 必红断言：不可达状态必须拒绝且不改 progress/DB；合法已登记 current 的一步提交窗口可以幂等续做。
- 准备状态：585 classify_progress 已证两种非法窗口拒绝、合法 before/after 接受；冻结后须确认 T2 真消费该校验，不把只测纯 parser 算协调器变异红。

### M10 · `same-path-A-fallback-to-fresh`

- 入口/证据：Task2 completed A canonical branch distinction；计划测试 `test_completed_original_backup_path_never_falls_back_to_fresh_noop`。
- 先证构造：由候选真正完成 from0→2 获得 state；移走原 A，再在相同 canonical A 路径创建实际当前 v2 合法备份。state 仍绑原 A/原 manifest，新的 A verify 通过且与 live 当前点相同。
- 隔离变异：A 校验失败后改走 fresh B 比较，企图成功 no-op。
- 必红断言：同原路径必须拒绝，保留原 progress 字节和 DB；不同 canonical B 的 fresh 正控独立成功。
- 准备状态：585 只能准备合法备份/机制输入；没有 T2 completed A，因此整条行为必须等 freeze 后真实创建，不手造完成许可。

### M11 · `audit-step-only-noop-B`

- 入口/证据：Task2 completed B full mechanism_digest；计划测试 `test_fresh_noop_compares_full_mechanism_audit_and_definitions`。
- 先证构造：候选真正完成；真实业务再写入、不同路径创建 v2 B、移走 A。正控 B 成功。随后独立变体改 B.applied_at、note、或等效显式 ASC index SQL；更新 manifest，使 verify/inspect 都通过且 audit.step=[1,2]、业务/材料不变。
- 隔离变异：mechanism 比较缩减为 audit.step 列表，忽略 typed 旧值和完整定义。
- 必红断言：各变体必须拒绝而原 B 成功；不要求旧 A 存在，不与历史 business baseline 强等。
- 准备状态：585 三个 audit/definition 变体全部 verify/inspect 通过、steps 相同、business 相同而完整 mechanism 不同，故不会停在 setup/普通版本检查。

### M12 · `noop-progress-refresh`

- 入口/证据：Task2 completed A/B read-only finish；计划测试 `test_completed_fresh_backup_noop_without_old_backup_or_rebinding; completed-A immediate repeat`。
- 先证构造：真实 completed A 与真实业务再写后 B 两个正控；记录所有关联 progress 原字节和 DB logical/schema/audit/版本。另用冻结后实际 writer 路径 spy 计数写入尝试，防同字节重写漏检。
- 隔离变异：no-op 调用状态 writer 刷新 updated_at、重绑 backup 或重写 audit；固定时钟碰巧同值时仍由写调用断言揭穿。
- 必红断言：A/B 成功报告必须符合计划；progress 字节、DB逻辑不变，progress 写尝试为0，B from=to=2/steps=[]/resumed=false/already_current=true。
- 准备状态：completed 对象尚无真实 T2 入口；writer alias/同 conn SQL 观察位置等冻结后确定，不把手造状态或纯日志当通过。

## 冻结后再做的有限工作

先接收作者完整freeze与T2公开API位置，并核对T1共享接口与批准范围。用候选真实migrate/库级硬退生成format2起始、续做和completed A/B；不手造完成状态替代。原候选配对正控先通过，再在独立完整源码副本执行各具名变异，失败必须命中相关行为或不变性断言，不能是import、collection或setup失败。保存精确diff、输入与日志hash；同一候选版本绑复审证据。

还须覆盖真实v0/v1首次绑定、同conn事务、无modern completed的v2拒绝、标准布局、I/O/DDL失败与资源释放等Task2计划验收项。实际writer alias、plan函数与mutant替换点目前未冻结，不先写猜测适配器。Task3的CLI、真实跨进程和四点CLI验收继续留在未授权范围。

## 最小可执行草案

`preflight_probe.py` 只执行预置事实；使用Python3.12及固定585源码。已继承的应用/provider环境键在import前被移除，再钉到合成data/authority根，不输出环境值。每次使用新的输出目录：

```sh
/Users/ronfee/.codex/worktrees/g3-data-admission/天枢Agent/.venv/bin/python /tmp/t2-admission-independent/preflight_probe.py --source /tmp/t2-admission-independent/source-585 --out /tmp/t2-admission-independent/replay-585-01
```

预置数据根在自核末尾已到v2、没有T2签发的format2 completion；不能将它直接冒充某个候选首次绑定的有效root。后续每个行为用例须重新通过真实接口建其专用起点。

最终冻结自核：`fixture-selfcheck-585-final/preflight-results.json`，exit=0；10组预置事实自核全部完成，继承step1 typed值断言已实际重跑。输出与76个合成文件固定于`fixed-fixture-index.json`；命令、stdout/stderr与退出码见`final-selfcheck-run.json`。266项固定源码摘要重新亲核无漂移，12个具名变异仍全部`NOT_RUN_AWAIT_AUTHOR_FREEZE`。

本预备阶段至此交权，等待作者freeze。没有T2行为通过、变异kill、full或CI结论。
