"""Independent Task2 behavior probes; no author test helper imports."""
from __future__ import annotations

import ast
import hashlib
import json
import os
import shutil
import sqlite3
import struct
import subprocess
import sys
from contextlib import closing, contextmanager
from dataclasses import replace
from pathlib import Path

import pytest

from tianshu import data_admission, data_digest, data_state, migrate
from tianshu.backup import create_backup, verify_backup
from tianshu.events import EventLog
from tianshu.loop import build_stack
from tianshu.memory_control import remember
from tianshu.memory_index import HashEmbeddingProvider
from tianshu.resources import MemoryScope


def h(raw):
    return hashlib.sha256(raw).hexdigest()


def atom(value):
    if value is None:
        return ["null"]
    if type(value) is int:
        return ["integer", str(value)]
    if type(value) is float:
        return ["float64", struct.pack(">d", value).hex()]
    if type(value) is str:
        return ["text", value]
    if type(value) is bytes:
        return ["blob", value.hex()]
    raise AssertionError(type(value).__name__)


def enc(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=True).encode()


def q(name):
    return '"' + name.replace('"', '""') + '"'


def records(conn, name):
    return sorted(([atom(v) for v in row] for row in conn.execute("SELECT * FROM " + q(name))), key=enc)


def observe(root):
    with closing(sqlite3.connect(root / "events.db")) as conn:
        schema = list(conn.execute("SELECT type,name,tbl_name,sql FROM sqlite_schema ORDER BY type,name"))
        tables = {r[1]: records(conn, r[1]) for r in schema if r[0] == "table"}
        version = conn.execute("PRAGMA user_version").fetchone()[0]
    files = {}
    for top in ("artifacts", "blobs", "memory_blobs"):
        for p in sorted((root / top).rglob("*")) if (root / top).exists() else []:
            if p.is_file():
                files[p.relative_to(root).as_posix()] = h(p.read_bytes())
    progress = {n: (root / n).read_bytes() if (root / n).exists() else None for n in ("events.db.migration.json", "migration.json")}
    return (version, schema, tables, files, progress)


@pytest.fixture(autouse=True)
def isolate(monkeypatch, tmp_path):
    monkeypatch.setenv("TIANSHU_AUTHORITY_ROOT", str(tmp_path / "authority"))
    monkeypatch.setenv("TIANSHU_DATA_ROOT", str(tmp_path / "unused-default-data"))
    monkeypatch.delenv("TIANSHU_FAILPOINT", raising=False)
    monkeypatch.delenv("TIANSHU_FAILPOINT_PATH", raising=False)
    yield


def make(base, origin=0):
    root = (base / "data").resolve()
    with closing(EventLog(root / "events.db", blob_dir=root / "artifacts/blobs")) as log:
        stack = build_stack(log, data_root=root, clock=lambda: 1700000000000, embedding_provider=HashEmbeddingProvider())
        stack.memory.ensure_schema()
        log.conn.execute("INSERT INTO memory_fts(memory_fts,rank) VALUES('automerge',0)")
        for i in range(6):
            assert remember(stack, MemoryScope.user(), kind="preference", content=f"Independent cobalt preference item {i}.").ok
        log.conn.execute("CREATE TABLE reviewer_extension(id INTEGER PRIMARY KEY AUTOINCREMENT,value BLOB)")
        log.conn.executemany("INSERT INTO reviewer_extension(value) VALUES(?)", [(None,), ("1",), (1,), (1.0,), (b"1",)])
        tables = {r[0] for r in log.conn.execute("SELECT name FROM sqlite_schema WHERE type='table'")}
        assert {"run_cursors", "summary_versions", "budget_reservations", "memory_vectors", "memory_fts_data", "memory_fts_idx", "sqlite_sequence"} <= tables
        assert [r[0] for r in log.conn.execute("SELECT typeof(value) FROM reviewer_extension ORDER BY id")] == ["null", "text", "integer", "real", "blob"]
        assert log.conn.execute("SELECT COUNT(*) FROM memories").fetchone()[0] == 6
        if origin:
            migrate._apply_step(log.conn, migrate.STEPS[0])
    return root


def backup(root, base, name="A"):
    saved = (base / name).resolve()
    create_backup(root, saved)
    assert verify_backup(saved).ok, "fixture must pass real backup verifier"
    return saved


def sql(root, statement):
    with closing(sqlite3.connect(root / "events.db", isolation_level=None)) as conn:
        conn.executescript(statement)


def reseal(saved):
    mp = saved / "backup.json"
    raw = json.loads(mp.read_bytes())
    with closing(sqlite3.connect(saved / "events.db")) as conn:
        raw["db_user_version"] = conn.execute("PRAGMA user_version").fetchone()[0]
    for entry in raw["files"]:
        content = (saved / entry["path"]).read_bytes()
        entry.update(size=len(content), sha256=h(content))
    mp.write_bytes(enc(raw))
    assert verify_backup(saved).ok, "legal variant must pass verifier before migrate"
    with closing(sqlite3.connect(saved / "events.db")) as conn:
        data_admission.inspect_connection(conn, saved / "events.db")


def reject(root, saved, code=None):
    before = observe(root)
    with pytest.raises(data_state.AdmissionRefused) as error:
        migrate.migrate(root, backup=saved)
    assert observe(root) == before, "refusal changed logical database/material/progress"
    if code:
        assert error.value.code == code
    print("REFUSAL", error.value.code, str(error.value))
    return error.value


def cut(root, saved, name):
    env = dict(os.environ)
    env["TIANSHU_FAILPOINT"] = name
    code = "from pathlib import Path; from tianshu.migrate import migrate; migrate(Path(" + repr(str(root)) + "),backup=Path(" + repr(str(saved)) + "))"
    child = subprocess.run([sys.executable, "-c", code], env=env, capture_output=True, text=True, timeout=30)
    assert child.returncode == 77, (child.returncode, child.stdout, child.stderr)
    assert f"[failpoint] {name}" in child.stderr
    state = json.loads((root / migrate.STATE_NAME).read_bytes())
    assert state["format_version"] == 2 and state["status"] == "in_progress"
    return state


def write_progress(root, raw):
    data_state.parse_state(raw)  # strict shape remains valid before reachability check
    (root / migrate.STATE_NAME).write_bytes(enc(raw))


@pytest.mark.parametrize("origin", [0, 1])
def test_real_positive_wal_single_connection_and_noop(tmp_path, monkeypatch, origin):
    root = make(tmp_path, origin)
    with closing(sqlite3.connect(root / "events.db", isolation_level=None)) as writer:
        writer.execute("PRAGMA wal_autocheckpoint=0")
        before_raw = h((root / "events.db").read_bytes())
        writer.execute("UPDATE reviewer_extension SET value=4242 WHERE id=3")
        assert h((root / "events.db").read_bytes()) == before_raw
        assert (root / "events.db-wal").stat().st_size > 0
        saved = backup(root, tmp_path)
        before = observe(root)
        held = False
        live = []
        calls = []
        access_original = migrate.acquire_database_access
        connect_original = migrate._connect

        @contextmanager
        def access(db, *, exclusive):
            nonlocal held
            assert exclusive
            with access_original(db, exclusive=True):
                held = True
                try:
                    yield
                finally:
                    held = False

        def connect(db):
            assert held
            conn = connect_original(db)
            live.append(conn)
            return conn

        monkeypatch.setattr(migrate, "acquire_database_access", access)
        monkeypatch.setattr(migrate, "_connect", connect)
        for name in ("inspect_connection", "sqlite_digest", "mechanism_digest", "_apply_step"):
            original = getattr(migrate, name)

            def wrapper(conn, *args, _name=name, _original=original):
                actual = conn.execute("PRAGMA database_list").fetchone()[2]
                if Path(actual) == root / "events.db":
                    assert held and conn is live[0]
                    calls.append(_name)
                return _original(conn, *args)

            monkeypatch.setattr(migrate, name, wrapper)
        report = migrate.migrate(root, backup=saved)
        assert report.from_version == origin and report.applied_steps == list(range(origin + 1, 3))
        assert len(live) == 1 and set(calls) == {"inspect_connection", "sqlite_digest", "mechanism_digest", "_apply_step"}
        assert observe(root)[2]["events"] == before[2]["events"]
        assert observe(root)[3] == before[3]
        with pytest.raises(sqlite3.ProgrammingError):
            live[0].execute("SELECT 1")
    with closing(EventLog(root / "events.db")) as log:
        for statement in ("UPDATE events SET actor_id='changed'", "DELETE FROM events"):
            with pytest.raises(sqlite3.IntegrityError):
                log.conn.execute(statement)


@pytest.mark.parametrize("origin,phase", [(0,p) for p in ("before-step-1", "after-step-1", "before-step-2", "after-step-2")] + [(1,p) for p in ("before-step-2", "after-step-2")])
def test_real_cut_resume(tmp_path, origin, phase):
    root = make(tmp_path, origin)
    old_audit = observe(root)[2].get("migration_log")
    saved = backup(root, tmp_path)
    events = observe(root)[2]["events"]
    cut(root, saved, "migration-" + phase)
    with pytest.raises(data_state.AdmissionRefused):
        EventLog(root / "events.db")
    report = migrate.migrate(root, backup=saved)
    assert report.resumed and report.to_version == 2
    state = migrate.read_state(root)
    assert state.status == "completed" and state.applied_steps == tuple(range(origin + 1, 3))
    assert observe(root)[2]["events"] == events
    if origin:
        assert observe(root)[2]["migration_log"][0][:2] == old_audit[0][:2]


@pytest.mark.parametrize("rel", ["artifacts/.orphan.tmp", "blobs/orphan", "memory_blobs/orphan"])
def test_M01_extra_live_material(tmp_path, rel):
    root = make(tmp_path)
    saved = backup(root, tmp_path)
    db_before = observe(root)[:3]
    p = root / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(b"unreferenced independent file")
    assert observe(root)[:3] == db_before and verify_backup(saved).ok
    reject(root, saved, "backup_mismatch")


@pytest.mark.parametrize("target", ["projection", "typed", "table", "index", "view", "trigger"])
def test_M02_non_event_business(tmp_path, target):
    root = make(tmp_path)
    saved = backup(root, tmp_path)
    event_rows = observe(root)[2]["events"]
    changes = {"projection": "UPDATE memories SET created_at=created_at+1", "typed": "UPDATE reviewer_extension SET value='1' WHERE id=3", "table": "CREATE TABLE new_persistent(v)", "index": "CREATE INDEX extension_index ON reviewer_extension(value)", "view": "CREATE VIEW extension_view AS SELECT * FROM reviewer_extension", "trigger": "CREATE TRIGGER extension_trigger AFTER INSERT ON reviewer_extension BEGIN SELECT 1; END"}
    sql(root, changes[target])
    assert observe(root)[2]["events"] == event_rows
    reject(root, saved, "backup_mismatch")


@pytest.mark.parametrize("mode", ["resume", "A"])
def test_M03_manifest_bytes(tmp_path, mode):
    root = make(tmp_path)
    saved = backup(root, tmp_path)
    if mode == "resume":
        cut(root, saved, "migration-before-step-1")
    else:
        migrate.migrate(root, backup=saved)
    mp = saved / "backup.json"
    raw = json.loads(mp.read_bytes())
    original = mp.read_bytes()
    raw["created_at_ms"] += 1
    mp.write_bytes(enc(raw))
    assert h(mp.read_bytes()) != h(original) and verify_backup(saved).ok
    reject(root, saved, "backup_mismatch")


@pytest.mark.parametrize("mode", ["resume", "A", "B"])
def test_M04_plan_binding(tmp_path, mode):
    root = make(tmp_path)
    saved = backup(root, tmp_path)
    if mode == "resume":
        raw = cut(root, saved, "migration-before-step-1")
    else:
        migrate.migrate(root, backup=saved)
        raw = json.loads((root / migrate.STATE_NAME).read_bytes())
    if mode == "B":
        saved = backup(root, tmp_path, "B")
    raw["plan_sha256"] = "0" * 64
    write_progress(root, raw)
    reject(root, saved, "progress_corrupt")


@pytest.mark.parametrize("mode", ["initial", "resume", "B"])
def test_M05_real_backup_version(tmp_path, mode):
    root = make(tmp_path)
    saved = backup(root, tmp_path)
    if mode == "resume":
        cut(root, saved, "migration-before-step-1")
    if mode == "B":
        migrate.migrate(root, backup=saved)
        saved = backup(root, tmp_path, "B")
        sql(saved, "DROP INDEX idx_migration_log_applied; DROP TABLE migration_log; PRAGMA user_version=0")
    else:
        with closing(sqlite3.connect(saved / "events.db", isolation_level=None)) as conn:
            migrate._apply_step(conn, migrate.STEPS[0])
    reseal(saved)
    if mode == "resume":
        # Keep manifest binding valid so this probe reaches the real-version guard.
        raw = json.loads((root / migrate.STATE_NAME).read_bytes())
        raw["backup"]["manifest_sha256"] = h((saved / "backup.json").read_bytes())
        write_progress(root, raw)
    reject(root, saved, "backup_mismatch")


def test_M06_initial_full_mechanism(tmp_path):
    root = make(tmp_path, 1)
    saved = backup(root, tmp_path)
    sql(saved, "UPDATE migration_log SET applied_at=applied_at+1")
    reseal(saved)
    reject(root, saved, "backup_mismatch")


@pytest.mark.parametrize("field", ["applied_at", "note"])
def test_M07_inherited_audit(tmp_path, field):
    root = make(tmp_path, 1)
    saved = backup(root, tmp_path)
    cut(root, saved, "migration-after-step-2")
    sql(root, "UPDATE migration_log SET " + ("applied_at=applied_at+1" if field == "applied_at" else "note='changed inherited'") + " WHERE step=1")
    reject(root, saved, "backup_mismatch")


def test_M08_real_fts_optimize(tmp_path):
    root = make(tmp_path)
    saved = backup(root, tmp_path)
    before = observe(root)
    with closing(sqlite3.connect(root / "events.db", isolation_level=None)) as conn:
        segments = conn.execute("SELECT COUNT(DISTINCT segid) FROM memory_fts_idx").fetchone()[0]
        assert segments > 1
        conn.execute("INSERT INTO memory_fts(memory_fts) VALUES('optimize')")
        assert conn.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
        assert conn.execute("SELECT COUNT(DISTINCT segid) FROM memory_fts_idx").fetchone()[0] < segments
    after = observe(root)
    for table in ("memory_fts", "memories", "events", "memory_vectors"):
        assert after[2][table] == before[2][table]
    assert after[2]["memory_fts_data"] != before[2]["memory_fts_data"]
    assert after[2]["memory_fts_idx"] != before[2]["memory_fts_idx"]
    reject(root, saved, "backup_mismatch")


@pytest.mark.parametrize("actual,done,current", [(1, [], None), (2, [], 1)])
def test_M09_unreachable_progress(tmp_path, actual, done, current):
    root = make(tmp_path)
    saved = backup(root, tmp_path)
    raw = cut(root, saved, f"migration-after-step-{actual}")
    raw.update(applied_steps=done, current_step=current)
    write_progress(root, raw)
    reject(root, saved, "progress_corrupt")


def test_M10_same_path_A_replacement(tmp_path):
    root = make(tmp_path)
    saved = backup(root, tmp_path)
    migrate.migrate(root, backup=saved)
    saved.rename(tmp_path / "moved-A")
    backup(root, tmp_path)
    reject(root, saved, "backup_mismatch")


@pytest.mark.parametrize("field", ["applied_at", "note", "definition"])
def test_M11_fresh_B_full_mechanism(tmp_path, field):
    root = make(tmp_path)
    saved = backup(root, tmp_path)
    migrate.migrate(root, backup=saved)
    sql(root, "UPDATE reviewer_extension SET value=5151 WHERE id=3")
    fresh = backup(root, tmp_path, "B")
    saved.rename(tmp_path / "moved-A")
    if field == "definition":
        sql(fresh, "DROP INDEX idx_migration_log_applied; CREATE INDEX idx_migration_log_applied ON migration_log(applied_at ASC)")
    else:
        sql(fresh, "UPDATE migration_log SET " + ("applied_at=applied_at+1" if field == "applied_at" else "note='legal alternate'") + " WHERE step=1")
    reseal(fresh)
    with closing(sqlite3.connect(fresh / "events.db")) as conn:
        assert [r[0] for r in conn.execute("SELECT step FROM migration_log ORDER BY step")] == [1, 2]
    reject(root, fresh, "backup_mismatch")


@pytest.mark.parametrize("branch", ["A", "B"])
def test_M12_noop_read_only(tmp_path, monkeypatch, branch):
    root = make(tmp_path)
    saved = backup(root, tmp_path)
    migrate.migrate(root, backup=saved)
    if branch == "B":
        with closing(EventLog(root / "events.db", blob_dir=root / "artifacts/blobs")) as log:
            stack = build_stack(log, data_root=root, embedding_provider=HashEmbeddingProvider())
            assert remember(stack, MemoryScope.user(), kind="preference", content="new legitimate business content after completion").ok
        fresh = backup(root, tmp_path, "B")
        saved.rename(tmp_path / "moved-A")
        saved = fresh
    before = observe(root)
    attempts = []
    original = migrate.atomic_write_bytes

    def spy(path, value):
        attempts.append(str(path))
        return original(path, value)

    monkeypatch.setattr(migrate, "atomic_write_bytes", spy)
    report = migrate.migrate(root, backup=saved)
    assert report.to_dict() | {} == {"from_version": 2, "to_version": 2, "applied_steps": [], "resumed": False, "already_current": True, "backup_path": str(saved), "event_count": len(before[2]["events"]), "warnings": []}
    assert observe(root) == before, "no-op modified database/material/progress"
    assert attempts == [], "no-op attempted progress publication even if bytes coincide"


@pytest.mark.parametrize("number", range(1, 7))
def test_state_io_failure_release_and_retry(tmp_path, monkeypatch, number):
    root = make(tmp_path)
    saved = backup(root, tmp_path)
    original = migrate.atomic_write_bytes
    calls = 0
    def failing(path, value):
        nonlocal calls
        calls += 1
        if calls == number:
            raise OSError("independent publication failure")
        return original(path, value)
    with monkeypatch.context() as mp:
        mp.setattr(migrate, "atomic_write_bytes", failing)
        with pytest.raises(migrate.MigrationFailed):
            migrate.migrate(root, backup=saved)
    state = migrate.read_state(root)
    assert state is None if number == 1 else state.status == "in_progress"
    with migrate.acquire_database_access(root / "events.db", exclusive=True):
        with closing(sqlite3.connect(root / "events.db", isolation_level=None)) as conn:
            conn.execute("BEGIN EXCLUSIVE")
            conn.rollback()
    assert migrate.migrate(root, backup=saved).to_version == 2


@pytest.mark.parametrize("step_number", [1, 2])
def test_step_ddl_rollback_release_and_retry(tmp_path, monkeypatch, step_number):
    root = make(tmp_path)
    saved = backup(root, tmp_path)
    original = migrate.MigrationStep.run
    def failing(step, conn):
        original(step, conn)
        if step.to_version == step_number:
            raise sqlite3.OperationalError("independent post-DDL error")
    with monkeypatch.context() as mp:
        mp.setattr(migrate.MigrationStep, "run", failing)
        with pytest.raises(migrate.MigrationFailed):
            migrate.migrate(root, backup=saved)
    with closing(sqlite3.connect(root / "events.db", isolation_level=None)) as conn:
        assert conn.execute("PRAGMA user_version").fetchone()[0] == step_number - 1
        if step_number == 1:
            assert conn.execute("SELECT 1 FROM sqlite_schema WHERE name='migration_log'").fetchone() is None
        else:
            assert [r[1] for r in conn.execute("PRAGMA table_info(migration_log)")] == ["step", "applied_at"]
            assert [r[0] for r in conn.execute("SELECT step FROM migration_log")] == [1]
    with migrate.acquire_database_access(root / "events.db", exclusive=True):
        pass
    assert migrate.migrate(root, backup=saved).resumed


@pytest.mark.parametrize("target", ["hardlink", "root", "db", "material"])
def test_layout_refused_without_progress(tmp_path, target):
    root = make(tmp_path)
    saved = backup(root, tmp_path)
    if target == "hardlink":
        os.link(root / "events.db", tmp_path / "alias.sqlite")
    else:
        path = root if target == "root" else root / ("events.db" if target == "db" else "memory_blobs")
        moved = tmp_path / (target + "-moved")
        path.rename(moved)
        path.symlink_to(moved, target_is_directory=target != "db")
    reject(root, saved, "incompatible")
    assert not (root / migrate.STATE_NAME).exists()


@pytest.mark.parametrize("suffix", ["-wal", "-journal", "-shm"])
def test_shared_preconnect_zero_history(tmp_path, monkeypatch, suffix):
    root = tmp_path / "data"
    root.mkdir()
    (root / "events.db").write_bytes(b"")
    (root / ("events.db" + suffix)).write_bytes(b"independent historical bytes")
    before = {p.name: p.read_bytes() for p in root.iterdir()}
    def forbidden(*args, **kwargs):
        raise AssertionError("SQLite called before zero-main historical evidence rejection")
    monkeypatch.setattr(migrate.sqlite3, "connect", forbidden)
    with pytest.raises(data_state.AdmissionRefused) as error:
        migrate.migrate(root, backup=tmp_path / "absent")
    assert error.value.code == "incompatible"
    assert {p.name: p.read_bytes() for p in root.iterdir()} == before


@pytest.mark.parametrize("legacy", [False, True])
def test_v2_without_modern_state_does_not_gain_permission(tmp_path, legacy):
    root = make(tmp_path)
    with closing(sqlite3.connect(root / "events.db", isolation_level=None)) as conn:
        for step in migrate.STEPS:
            migrate._apply_step(conn, step)
    if legacy:
        fixture = Path(os.environ["T2_SOURCE"]) / "tests/fixtures/data_admission/legacy-completed.json"
        (root / "migration.json").write_bytes(fixture.read_bytes())
        EventLog(root / "events.db").close()
    saved = backup(root, tmp_path)
    reject(root, saved, "migration_incomplete")
    assert not (root / migrate.STATE_NAME).exists()


def test_shared_types_no_second_parser_and_fixed_t1():
    assert migrate.MigrationState is data_state.MigrationState
    assert migrate.MigrationStateCorrupt is data_state.MigrationStateCorrupt
    tree = ast.parse(Path(migrate.__file__).read_text())
    assert not any(isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and ("parse" in n.name or "coerce" in n.name) for n in ast.walk(tree))
    tree = ast.parse(Path(data_digest.__file__).read_text())
    assert {n.module for n in ast.walk(tree) if isinstance(n, ast.ImportFrom) and n.level} == {"data_state"}


REACHABLE_FORMS = {0: [((), None), ((), 1), ((1,), None), ((1,), 2), ((1, 2), None)], 1: [((), None), ((), 2), ((2,), None)]}


@pytest.mark.parametrize("origin,actual,done,current", [(origin, actual, done, current) for origin, forms in REACHABLE_FORMS.items() for actual in range(origin, 3) for done, current in forms])
def test_exhaustive_strict_library_reachability(tmp_path, origin, actual, done, current):
    root = make(tmp_path, origin)
    saved = backup(root, tmp_path)
    phase = f"after-step-{actual}" if actual > origin else f"before-step-{origin + 1}"
    raw = cut(root, saved, "migration-" + phase)
    raw.update(applied_steps=list(done), current_step=current)
    write_progress(root, raw)
    done_version = done[-1] if done else origin
    allowed = actual == done_version or current is not None and actual == current
    if not allowed:
        reject(root, saved, "progress_corrupt")
    else:
        assert migrate.migrate(root, backup=saved).resumed
        final = migrate.read_state(root)
        assert final.status == "completed" and final.applied_steps == tuple(range(origin + 1, 3))


def test_digest_exact_values_metadata_and_stability():
    with closing(sqlite3.connect(":memory:", isolation_level=None)) as conn:
        conn.execute("CREATE TABLE typed(value)")
        values = []
        for value in (None, "1", 1, 1.0, b"1"):
            conn.execute("DELETE FROM typed")
            conn.execute("INSERT INTO typed VALUES(?)", (value,))
            values.append(data_digest.sqlite_digest(conn))
        assert len(set(values)) == 5
        conn.executescript('CREATE TABLE auto(id INTEGER PRIMARY KEY AUTOINCREMENT,v); INSERT INTO auto(v) VALUES(3),(3); CREATE TABLE "odd name"(k TEXT PRIMARY KEY,v) WITHOUT ROWID; INSERT INTO "odd name" VALUES (\'b\',2),(\'a\',1); CREATE TABLE generated(x,y GENERATED ALWAYS AS (x*2) STORED); INSERT INTO generated(x) VALUES(4);')
        baseline = data_digest.sqlite_digest(conn)
        for statement in ("UPDATE typed SET rowid=80", "UPDATE sqlite_sequence SET seq=80", "DELETE FROM auto WHERE id=1", "UPDATE generated SET x=6", 'UPDATE "odd name" SET v=9 WHERE k=\'a\''):
            conn.execute("BEGIN")
            conn.execute(statement)
            assert conn.in_transaction
            assert data_digest.sqlite_digest(conn) != baseline
            assert conn.in_transaction
            conn.rollback()
        conn.execute('DELETE FROM "odd name"')
        conn.execute('INSERT INTO "odd name" VALUES(\'a\',1),(\'b\',2)')
        assert data_digest.sqlite_digest(conn) == baseline
        conn.execute("VACUUM")
        assert data_digest.sqlite_digest(conn) == baseline
        conn.execute("CREATE TABLE aliases(rowid,_rowid_,oid)")
        with pytest.raises(data_state.AdmissionRefused, match="rowid"):
            data_digest.sqlite_digest(conn)


def test_digest_unreadable_text_fails_closed():
    with closing(sqlite3.connect(":memory:", isolation_level=None)) as conn:
        conn.execute("CREATE TABLE bad(v TEXT)")
        conn.execute("INSERT INTO bad VALUES(CAST(X'ff' AS TEXT))")
        with pytest.raises(data_state.AdmissionRefused):
            data_digest.sqlite_digest(conn)


@pytest.mark.parametrize("kind", ["index", "trigger"])
def test_attached_unknown_mechanism_objects_stay_business(tmp_path, kind):
    root = make(tmp_path, 1)
    saved = backup(root, tmp_path)
    with closing(sqlite3.connect(root / "events.db", isolation_level=None)) as conn:
        old = data_digest.sqlite_digest(conn)
        conn.execute("CREATE INDEX outside_owned_names ON migration_log(step)" if kind == "index" else "CREATE TRIGGER outside_owned_names AFTER INSERT ON migration_log BEGIN SELECT 1; END")
        assert data_digest.sqlite_digest(conn) != old
    reject(root, saved, "backup_mismatch")


def test_post_lock_layout_recheck(tmp_path, monkeypatch):
    root = make(tmp_path)
    saved = backup(root, tmp_path)
    original = migrate.acquire_database_access
    @contextmanager
    def late_link(db, *, exclusive):
        with original(db, exclusive=exclusive):
            os.link(db, tmp_path / "late.sqlite")
            yield
    monkeypatch.setattr(migrate, "acquire_database_access", late_link)
    reject(root, saved, "incompatible")
    assert not (root / migrate.STATE_NAME).exists()

