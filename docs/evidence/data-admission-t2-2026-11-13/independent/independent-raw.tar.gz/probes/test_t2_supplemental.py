"""Two additional no-op attempts with fixed time and both associated sidecars."""
import json
import os
import sqlite3
from contextlib import closing
from pathlib import Path

import pytest

from test_t2_independent import make, backup, observe, migrate, EventLog, isolate


@pytest.mark.parametrize("branch", ["A", "B"])
def test_noop_never_republishes_identical_bytes(tmp_path, monkeypatch, branch):
    root = make(tmp_path)
    saved = backup(root, tmp_path)
    migrate.migrate(root, backup=saved)
    fixture = Path(os.environ["T2_SOURCE"]) / "tests/fixtures/data_admission/legacy-completed.json"
    (root / "migration.json").write_bytes(fixture.read_bytes())
    EventLog(root / "events.db").close()
    if branch == "B":
        with closing(sqlite3.connect(root / "events.db")) as conn:
            conn.execute("UPDATE reviewer_extension SET value=8080 WHERE id=3")
        fresh = backup(root, tmp_path, "B")
        saved.rename(tmp_path / "moved-A")
        saved = fresh
    before = observe(root)
    attempts = []
    original = migrate.atomic_write_bytes
    def spy(path, body):
        attempts.append({"path": str(path), "same_bytes": path.read_bytes() == body})
        return original(path, body)
    monkeypatch.setattr(migrate, "atomic_write_bytes", spy)
    monkeypatch.setattr(migrate.time, "time", lambda: 0)
    assert migrate.migrate(root, backup=saved).already_current
    assert observe(root) == before, "fixed-clock no-op should have identical before/after bytes"
    print("PUBLICATION_ATTEMPTS", json.dumps(attempts))
    assert attempts == [], "no-op attempted publication of identical progress bytes"
