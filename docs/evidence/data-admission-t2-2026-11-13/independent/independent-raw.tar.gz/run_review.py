"""Reproduce frozen Task2 independent runs and single-protection mutants."""
from __future__ import annotations
import argparse
import ast
import difflib
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
BASE = ROOT / "candidate-frozen"
PYTHON = "/Users/ronfee/.codex/worktrees/g3-data-admission/天枢Agent/.venv/bin/python"
PROBE = ROOT / "probes/test_t2_independent.py"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def replace_once(text, old, new):
    assert text.count(old) == 1, (text.count(old), old)
    return text.replace(old, new)


def replace_function(text, name, replacement):
    node = next(n for n in ast.parse(text).body if isinstance(n, ast.FunctionDef) and n.name == name)
    lines = text.splitlines(keepends=True)
    return "".join(lines[:node.lineno - 1]) + replacement.rstrip() + "\n" + "".join(lines[node.end_lineno:])


def mutate(name, source):
    migrate = source / "src/tianshu/migrate.py"
    digest = source / "src/tianshu/data_digest.py"
    state = source / "src/tianshu/data_state.py"
    path = digest if name in ("M02", "M08") else state if name == "M09" else migrate
    text = path.read_text()
    if name == "M01":
        text = replace_once(text, "or live != actual or actual != declared:", "or actual != declared:")
    elif name == "M02":
        text = replace_function(text, "sqlite_digest", '''def sqlite_digest(conn):
    with _snapshot(conn):
        _mechanism_snapshot(conn)
        return hashlib.sha256(_encode(sorted(_encode([_atom(v) for v in row]).decode("ascii") for row in conn.execute("SELECT * FROM events")))).hexdigest()
''')
    elif name == "M03":
        text = replace_once(text, 'state.backup.path != str(saved) or state.backup.manifest_sha256 != raw_hash', 'state.backup.path != str(saved)')
    elif name == "M04":
        old = 'state.plan_sha256 != _plan_digest()'
        assert text.count(old) == 2
        text = text.replace(old, 'False')
    elif name == "M05":
        text = replace_once(text, 'if source.execute("PRAGMA user_version").fetchone()[0] != state.from_version:', 'if False:')
        text = replace_once(text, 'source.execute("PRAGMA user_version").fetchone()[0] != 2 or mechanism_digest(', 'mechanism_digest(')
        text = replace_once(text, 'if source.execute("PRAGMA user_version").fetchone()[\n                    0\n                ] != origin or mechanism_digest(source) != mechanism_digest(conn):', 'if mechanism_digest(source) != mechanism_digest(conn):')
    elif name == "M06":
        text = replace_once(text, '] != origin or mechanism_digest(source) != mechanism_digest(conn):', '] != origin:')
    elif name == "M07":
        old = '        if mechanism_digest(expected) != mechanism_digest(live):'
        new = '''        for row in current["rows"]:
            if row[0] <= origin:
                if current["version"] == 2:
                    expected.execute("UPDATE migration_log SET applied_at=?,note=? WHERE step=?", (row[1],row[2],row[0]))
                else:
                    expected.execute("UPDATE migration_log SET applied_at=? WHERE step=?", (row[1],row[0]))
        if mechanism_digest(expected) != mechanism_digest(live):'''
        text = replace_once(text, old, new)
    elif name == "M08":
        text = replace_once(text, '            if kind != "table":\n                continue', '            if kind != "table" or flags[name][0] == "shadow":\n                continue')
    elif name == "M09":
        text = replace_function(text, 'classify_progress', '''def classify_progress(state, actual_version):
    if type(state) is not MigrationStateV2:
        raise MigrationStateCorrupt("legacy cannot resume")
    state.__post_init__()
    _integer(actual_version, "actual_version")
    if state.status == "completed" and actual_version == state.target_version:
        return "completed"
    if state.status == "in_progress" and state.from_version <= actual_version <= state.target_version:
        # Deliberately restore the legacy numeric-union coercion at the shared guard.
        object.__setattr__(state, "applied_steps", tuple(sorted(set(state.applied_steps) | set(range(state.from_version + 1, actual_version + 1)))))
        if state.current_step is not None and state.current_step <= actual_version:
            object.__setattr__(state, "current_step", None)
        return "idle" if state.current_step is None else "before_step"
    raise MigrationStateCorrupt("unreachable")
''')
    elif name == "M10":
        text = replace_once(text, 'fresh = state.status == "completed" and str(saved) != state.backup.path', 'fresh = state.status == "completed" and (str(saved) != state.backup.path or raw_hash != state.backup.manifest_sha256)')
    elif name == "M11":
        text = replace_once(text, 'mechanism_digest(\n                        source\n                    ) != mechanism_digest(conn)', '[r[0] for r in source.execute("SELECT step FROM migration_log ORDER BY step")] != [r[0] for r in conn.execute("SELECT step FROM migration_log ORDER BY step")]')
    elif name == "M12":
        text = replace_once(text, '                if state.status == "completed":\n                    return MigrationReport(', '                if state.status == "completed":\n                    _write_state(root, state)\n                    return MigrationReport(')
    else:
        raise AssertionError(name)
    compile(text, str(path), "exec")
    old = path.read_text()
    path.write_text(text)
    diff = "".join(difflib.unified_diff(old.splitlines(keepends=True), text.splitlines(keepends=True), fromfile="candidate/" + str(path.relative_to(source)), tofile=name + "/" + str(path.relative_to(source))))
    diff_path = ROOT / "diffs" / (name + ".patch")
    diff_path.parent.mkdir(exist_ok=True)
    diff_path.write_text(diff)
    return {"file": str(path.relative_to(source)), "before_sha256": hashlib.sha256(old.encode()).hexdigest(), "after_sha256": sha(path), "diff": str(diff_path), "diff_sha256": sha(diff_path)}


def run(name, source, selected=None, regression=False):
    logs = ROOT / "logs"
    logs.mkdir(exist_ok=True)
    (ROOT / "runs").mkdir(exist_ok=True)
    env = {k: v for k, v in os.environ.items() if not (k.startswith("TIANSHU_") or k.endswith("BASE_URL") or k.endswith("API_KEY"))}
    env.update(PYTHONPATH=str(source / "src") + (os.pathsep + str(source / "tests") if regression else ""), T2_SOURCE=str(source), PYTHONDONTWRITEBYTECODE="1")
    cmd = [PYTHON, "-m", "pytest", "-c", "/dev/null", "-o", "addopts=", "-vv", "-s", "-p", "no:cacheprovider"]
    if regression:
        cmd += [str(source / "tests" / name) for name in ("test_data_binding.py", "test_migration.py", "test_backup.py", "test_backup_materials.py", "test_data_state.py", "test_data_admission.py")]
    else:
        cmd += [str(PROBE)]
    if selected:
        cmd += ["-k", selected]
    cmd += ["--basetemp", str(ROOT / "runs" / name), "--junitxml", str(logs / (name + ".xml"))]
    assert not (logs / (name + "-run.json")).exists(), name
    start = time.monotonic()
    result = subprocess.run(cmd, cwd=source, env=env, capture_output=True, text=True, timeout=180)
    (logs / (name + ".stdout.log")).write_text(result.stdout)
    (logs / (name + ".stderr.log")).write_text(result.stderr)
    xml = ET.parse(logs / (name + ".xml")).getroot()
    suites = [xml] if xml.tag == "testsuite" else list(xml)
    counts = {k: sum(int(s.attrib.get(k, 0)) for s in suites) for k in ("tests", "failures", "errors", "skipped")}
    tests = [{"name": c.attrib["name"], "status": "failed" if c.find("failure") is not None else "error" if c.find("error") is not None else "skipped" if c.find("skipped") is not None else "passed", "message": (c.find("failure").attrib.get("message") if c.find("failure") is not None else c.find("error").attrib.get("message") if c.find("error") is not None else None)} for c in xml.iter("testcase")]
    record = {"command": cmd, "source": str(source), "exit": result.returncode, "seconds": round(time.monotonic() - start, 3), "probe_sha256": sha(PROBE), "counts": counts, "tests": tests, "stdout_sha256": sha(logs / (name + ".stdout.log")), "stderr_sha256": sha(logs / (name + ".stderr.log"))}
    (logs / (name + "-run.json")).write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({k: record[k] for k in ("source", "exit", "seconds", "counts")}, ensure_ascii=False), flush=True)
    return record


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("lane", choices=["baseline", "mutants", "regression"])
    args = parser.parse_args()
    if args.lane == "baseline":
        result = run("candidate-positive-final", BASE)
        raise SystemExit(result["exit"])
    if args.lane == "regression":
        result = run("candidate-targeted-regression", BASE, regression=True)
        raise SystemExit(result["exit"])
    results = []
    for number in range(1, 13):
        name = f"M{number:02d}"
        source = ROOT / "mutants" / name
        assert not source.exists(), source
        shutil.copytree(BASE, source, ignore=shutil.ignore_patterns("__pycache__", ".pytest_cache"))
        change = mutate(name, source)
        record = run("mutant-" + name, source, name + " or real_positive_wal_single_connection")
        positive = [t for t in record["tests"] if "test_real_positive_" in t["name"]]
        targets = [t for t in record["tests"] if name in t["name"]]
        assert len(positive) == 2 and all(t["status"] == "passed" for t in positive), (name, positive)
        entry = {"id": name, "mutation": change, "run_record": str(ROOT / "logs" / ("mutant-" + name + "-run.json")), "positive_controls": len(positive), "targets": targets, "counts": record["counts"], "exit": record["exit"], "status": "BEHAVIOR_OR_INVARIANCE_FAILURE_REQUIRES_REVIEW" if any(t["status"] == "failed" for t in targets) else "STILL_REFUSED_BY_RETAINED_GUARD" if all(t["status"] == "passed" for t in targets) else "INVALID_MUTANT_RUN"}
        results.append(entry)
        (ROOT / "mutation-results.json").write_text(json.dumps(results, ensure_ascii=False, indent=2) + "\n")


if __name__ == "__main__":
    main()
