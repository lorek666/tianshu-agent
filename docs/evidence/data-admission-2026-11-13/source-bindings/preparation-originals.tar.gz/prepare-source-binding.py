#!/usr/bin/env python3
"""只读核对 Git/独立冻结源；只向本目录写准备材料，不执行产品或测试。"""
from __future__ import annotations

import difflib
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess

REPO = Path('/Users/ronfee/.codex/worktrees/windows-ci-fix/天枢Agent')
OUT = Path(__file__).resolve().parent
BASE = '585e3474b7f9f03bb118308470fac1f500c3a02e'
CONTENT = 'c145953e733533b7c9773d900af76a1dde2c7b37'
MAIN = '0df7019aeed4f9116262e38f86561d5eff06d0e4'
COMMON = '91290950099b1202beeb9b34cd2d71af7e945118'
T2 = Path('/tmp/t2-admission-independent/candidate-frozen')
T3 = Path('/tmp/t3-admission-independent/candidate-frozen')
KN = 'docs/KNOWLEDGE.md'
CONTRACT = 'docs/data-admission-contract.md'
PLAN = 'docs/evidence/data-admission-plan-2026-11-13/admission-implementation-plan.md'
FIXED_HASHES = {
    '/tmp/t1-admission/final-585-commit-binding.json': 'e10f905ca1605d4caacd177d5cd3f0b397ec62fc00e92eca98874c1f48fa5cb7',
    '/tmp/t1-admission/independent-review.md': 'c28a14d1b6ed4aab7b5999bcc973c61c72f5095587c743280f753d6fce4c2594',
    '/tmp/t1-admission/independent-evidence.json': '35ca1e539818d598cb883484d4f5964248d7602c96fe890d3adec63d404be744',
    '/tmp/t1-admission/recovery-fixture-independent-review.md': '9d053c14681070cc41bc2c432782be03c09713133823d8633c1c7b796fdd3b19',
    '/tmp/t1-admission/recovery-fixture-independent-evidence.json': '74cdd41e594a103a2f8559fa6fa57bb9de1b449181452b4992ebc1b293c38689',
    '/tmp/t2-admission/handoff-manifest.json': 'dddec59d87775811550493c535efee2fdc30faff199c41bb6bdbf9c80598c68a',
    '/tmp/t2-admission-independent/independent-review.md': 'b1cd6e2473184bef683c702bf2fcd08159888fb555633371ce81bcb6334648d1',
    '/tmp/t2-admission-independent/independent-review.json': '68c29faa4900a3ea65760ed79837553db6f1010dce788b7239f12386ecc8517d',
    '/tmp/t2-admission-independent/candidate-binding.json': 'fd215d2a6347b017f7b4120fb53f6caf752d238156bc132a8965ab1d89f42042',
    '/tmp/t3-admission/handoff-manifest.json': '79f5287dcf3719816649ffd49386e6087e04afb7f3e3810735d84164b7c828ee',
    '/tmp/t3-admission-independent/candidate-binding.json': '8ee219c4ec1304d48fab4d2dd24f8c7d7abb14dfa7d6ac345092a3a2e1f25fdd',
}


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def git(*args: str) -> bytes:
    env = dict(os.environ, GIT_OPTIONAL_LOCKS='0')
    return subprocess.check_output(['git', *args], cwd=REPO, env=env)


def blob_hash(data: bytes) -> str:
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()


def tree(commit: str) -> dict[str, dict[str, str]]:
    entries = {}
    for line in git('ls-tree', '-r', '-z', commit).split(b'\0'):
        if not line:
            continue
        metadata, path = line.split(b'\t', 1)
        mode, kind, oid = metadata.decode().split()
        if kind != 'blob':
            raise ValueError(f'非 blob 对象需单独处理: {path!r}')
        entries[path.decode()] = {'mode': mode, 'kind': kind, 'git_blob': oid}
    return entries


def read_blobs(entries: dict[str, dict[str, str]]) -> dict[str, bytes]:
    names = list(entries)
    request = ''.join(entries[name]['git_blob'] + '\n' for name in names).encode()
    output = subprocess.check_output(
        ['git', 'cat-file', '--batch'], input=request, cwd=REPO,
        env=dict(os.environ, GIT_OPTIONAL_LOCKS='0'))
    result = {}
    offset = 0
    for name in names:
        end = output.index(b'\n', offset)
        oid, kind, size = output[offset:end].decode().split()
        size = int(size)
        data = output[end + 1:end + 1 + size]
        if oid != entries[name]['git_blob'] or kind != 'blob' or blob_hash(data) != oid:
            raise ValueError(f'Git 对象读取不一致: {name}')
        result[name] = data
        offset = end + size + 2
    if offset != len(output):
        raise ValueError('Git batch 输出未完整消费')
    return result


def snapshot(root: Path) -> tuple[dict[str, bytes], dict[str, str]]:
    content, modes = {}, {}
    for path in sorted(root.rglob('*')):
        if path.is_symlink():
            raise ValueError(f'冻结目录出现 symlink: {path}')
        if path.is_file():
            relative = path.relative_to(root).as_posix()
            content[relative] = path.read_bytes()
            modes[relative] = oct(stat.S_IMODE(path.stat().st_mode))
    return content, modes


def write_json(name: str, value: object) -> None:
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def main() -> None:
    evidence, inputs = {}, {}
    for name, expected in FIXED_HASHES.items():
        data = Path(name).read_bytes()
        actual = sha(data)
        if actual != expected:
            raise ValueError(f'固定输入漂移: {name}: {actual}')
        evidence[name] = {'sha256': actual, 'bytes': len(data)}
        if name.endswith('.json'):
            inputs[name] = json.loads(data)

    t1 = inputs['/tmp/t1-admission/final-585-commit-binding.json']
    t1_content = inputs['/tmp/t1-admission/independent-evidence.json']
    fixture = inputs['/tmp/t1-admission/recovery-fixture-independent-evidence.json']
    h2 = inputs['/tmp/t2-admission/handoff-manifest.json']
    r2 = inputs['/tmp/t2-admission-independent/independent-review.json']
    b2 = inputs['/tmp/t2-admission-independent/candidate-binding.json']
    h3 = inputs['/tmp/t3-admission/handoff-manifest.json']
    b3 = inputs['/tmp/t3-admission-independent/candidate-binding.json']
    assert t1['final_commit'] == h2['base'] == h3['base'] == BASE
    assert t1['verdict'] == 'PASS_FINAL_585_COMMIT_BINDING_ONLY'
    assert t1_content['verdict'] == 'PASS_T1_CONTENT_ONLY'
    assert fixture['verdict'] == 'PASS_FIXTURE_INTEGRATION_ONLY'
    assert r2['verdict'] == 'PASS_TASK2_CONTENT_ONLY' and r2['pending_task2_findings'] == 0
    assert r2['binding']['handoff_manifest_sha256'] == FIXED_HASHES['/tmp/t2-admission/handoff-manifest.json']
    assert h3['t2_handoff_sha256'] == FIXED_HASHES['/tmp/t2-admission/handoff-manifest.json']
    assert b3['author_handoff_sha256'] == FIXED_HASHES['/tmp/t3-admission/handoff-manifest.json']
    assert b2['overlay_sha256'] == h2['files'] == r2['binding']['overlay_files']

    base_tree, content_tree, main_tree, common_tree = map(tree, [BASE, CONTENT, MAIN, COMMON])
    base_bytes = read_blobs(base_tree)
    base_hashes = {p: sha(data) for p, data in base_bytes.items()}
    t2_bytes, t2_modes = snapshot(T2)
    t3_bytes, t3_modes = snapshot(T3)
    t2_hashes = {p: sha(data) for p, data in t2_bytes.items()}
    t3_hashes = {p: sha(data) for p, data in t3_bytes.items()}
    expected_t2 = base_hashes | h2['files']
    expected_t3 = expected_t2 | h3['files']
    assert t2_hashes == expected_t2 == b2['frozen_files']
    assert t3_hashes == expected_t3 == b3['files']
    assert len(h2['files']) == 25 and len(h3['files']) == 26
    assert set(h2['files']) & set(h3['files']) == {KN}
    assert all(t2_hashes[p] == t3_hashes[p] for p in h2['files'] if p != KN)
    prior_approval_archive = []
    for record in t1['prior_approvals']:
        local_path = '/tmp/t1-admission/' + record['name']
        archived_path = 'docs/evidence/data-admission-t1-2026-11-13/' + record['name']
        assert FIXED_HASHES[local_path] == record['sha256'] == base_hashes[archived_path]
        prior_approval_archive.append({'path': archived_path, 'sha256': record['sha256'],
                                       'local_and_git585_archive_exact': True})

    # 用独立结论绑定的原件与 Git 对象核继承，不读取作者自评。
    inheritance = []
    t1_records = t1['t1_nine'] + [t1['fixture']]
    assert len(t1_records) == 10
    for record in t1_records:
        path, expected = record['path'], record['sha256']
        assert base_hashes[path] == t2_hashes[path] == t3_hashes[path] == expected
        assert content_tree[path] == base_tree[path]
        if path != fixture['fixture_path']:
            assert t1_content['uncommitted_source_set'][path] == expected
        else:
            assert fixture['fixture_sha256'] == expected
        inheritance.append({'task': 'T1+recovery-fixture', 'path': path,
                            'sha256': expected, **base_tree[path],
                            'c145_585_t2_t3_exact': True})
    for task, manifest, count in [('T2', h2, 4), ('T3', h3, 3)]:
        non_docs = {p: value for p, value in manifest['files'].items() if not p.startswith('docs/')}
        assert len(non_docs) == count
        for path, expected in non_docs.items():
            assert t3_hashes[path] == expected
            if task == 'T2':
                assert t2_hashes[path] == expected
            inheritance.append({'task': task, 'path': path, 'sha256': expected,
                                'git_blob': blob_hash(t3_bytes[path]),
                                'expected_mode': base_tree.get(path, {}).get('mode', '100644'),
                                'source_snapshot': str(T2 if task == 'T2' else T3),
                                'source_match': True,
                                'behavior_verdict': 'PASS_TASK2_CONTENT_ONLY' if task == 'T2' else 'PENDING_SEPARATE_INDEPENDENT_REVIEW'})

    authority_hashes = {
        CONTRACT: 'c62dba28c2e4b4c2d17ce100da233ea26c71f8dcea5f4c0611608fbabf2f8584',
        PLAN: '464849b2ea0f6e5a0dde4b00b4aed00b72d1e51c9af9bdda4d7d38d7eafde875',
    }
    for path, expected in authority_hashes.items():
        assert base_hashes[path] == t2_hashes[path] == t3_hashes[path] == expected

    merge_base = git('merge-base', BASE, MAIN).decode().strip()
    assert merge_base == COMMON
    main_delta = sorted(p for p in set(common_tree) | set(main_tree) if common_tree.get(p) != main_tree.get(p))
    expected_main_delta = [KN,
        'docs/evidence/data-lifecycle-2026-11-13/pr134-b5-ci-evidence-sha256.json',
        'docs/evidence/data-lifecycle-2026-11-13/pr134-b5-ci-independent-review.json',
        'docs/evidence/data-lifecycle-2026-11-13/pr134-b5-ci-independent-review.md']
    assert main_delta == sorted(expected_main_delta)
    main_data = read_blobs({p: main_tree[p] for p in main_delta})
    main_delta_records = [{'path': p, 'status': 'modified' if p in common_tree else 'added',
                           'sha256': sha(main_data[p]), **main_tree[p],
                           'integration_policy': 'MANUAL_FACT_MERGE_PENDING' if p == KN else 'INHERIT_EXACT_MAIN_OBJECT'}
                          for p in main_delta]

    old_kn = t2_bytes[KN].decode().splitlines(keepends=True)
    new_kn = t3_bytes[KN].decode().splitlines(keepends=True)
    kn_changes = [{'operation': op, 't2_lines_0_based': [a, b], 't3_lines_0_based': [c, d]}
                  for op, a, b, c, d in difflib.SequenceMatcher(None, old_kn, new_kn, autojunk=False).get_opcodes()
                  if op != 'equal']
    assert all(item['operation'] == 'insert' for item in kn_changes)

    # 父会话提供的合并方案仍在 /tmp；只核其继承，不替作者树落地。
    proposed_path = OUT / 'knowledge-after-main-sync.md'
    proposed_bytes = proposed_path.read_bytes()
    assert sha(proposed_bytes) == 'd7426e9dbba1c56f67f05b8b760dd48db9bd103050f9a326c1d052b0d180971e'
    common_kn = git('show', COMMON + ':' + KN).decode().splitlines(keepends=True)
    main_kn = main_data[KN].decode().splitlines(keepends=True)
    proposed_kn = proposed_bytes.decode().splitlines(keepends=True)

    def inserted_blocks(old: list[str], new: list[str]) -> list[list[str]]:
        changes = [(op, c, d) for op, a, b, c, d in
                   difflib.SequenceMatcher(None, old, new, autojunk=False).get_opcodes() if op != 'equal']
        assert len(changes) == 2 and all(op == 'insert' for op, c, d in changes)
        return [new[c:d] for op, c, d in changes]

    assert inserted_blocks(common_kn, main_kn) == inserted_blocks(new_kn, proposed_kn)
    proposed_knowledge = {'source_path': str(proposed_path), 'sha256': sha(proposed_bytes),
                          'git_blob': blob_hash(proposed_bytes), 'expected_mode': base_tree[KN]['mode'],
                          'all_t3_lines_preserved': True, 'exact_main_only_insertions': True,
                          'main_inserted_blocks': 2, 'main_inserted_lines': 4,
                          'status': 'TMP_PROPOSAL_VERIFIED_NOT_APPLIED'}

    objects = {}
    for path in sorted(expected_t3):
        source = 'T3' if path in h3['files'] else 'T2' if path in h2['files'] else 'Git585'
        obj = base_tree[path].copy() if source == 'Git585' else {
            'kind': 'blob', 'git_blob': blob_hash(t3_bytes[path]),
            'mode': base_tree.get(path, {}).get('mode', '100644')}
        objects[path] = {'source': source, 'sha256': expected_t3[path], **obj,
                         'bytes': len(t3_bytes[path]), 'snapshot_mode': t3_modes[path],
                         'source_path': f'{BASE}:{path}' if source == 'Git585' else str((T3 if source == 'T3' else T2) / path)}
    non_docs = [p for p in objects if not p.startswith('docs/')]
    assert len(objects) == 485 and len(non_docs) == 267
    new_from_main = [p for p in main_delta if p != KN]
    assert not set(new_from_main) & set(objects)

    write_json('source-object-map.json', {
        'stage': 'PREPARATION_ONLY', 'scope': 'Git585 + exact frozen T2/T3 overlays; before actual main sync/final facts archival',
        'base_commit': BASE, 'file_count': len(objects), 'non_docs_count': len(non_docs),
        'overlay_union_count': len(set(h2['files']) | set(h3['files'])), 'files': objects})
    write_json('source-preparation.json', {
        'date': '2026-11-13', 'reviewer': '/root/verify_lifecycle', 'verdict': 'PREPARATION_ONLY',
        'scope': 'source bytes/object inheritance and later acceptance checklist only; no new behavioral approval',
        'cwd': str(REPO), 'cwd_head': git('rev-parse', 'HEAD').decode().strip(),
        'cwd_status_at_preparation': git('status', '--short', '--branch').decode().strip(),
        'fixed_inputs': evidence,
        't1_prior_approval_archive_binding': prior_approval_archive,
        'counts': {'git585': len(base_tree), 't2_overlay': 25, 't2_candidate': len(t2_hashes),
                   't3_overlay': 26, 'combined_overlay': 50, 't3_candidate': len(t3_hashes),
                   'expected_non_docs': len(non_docs), 't1_nine_and_fixture': 10,
                   't2_product_test': 4, 't3_product_test': 3,
                   'main_delta': len(main_delta), 'pre_final_facts_after_main_sync': len(objects) + len(new_from_main)},
        'source_checks': {'all_t2_463_bytes_match_git585_plus_manifest': True,
                          'all_t3_485_bytes_match_git585_plus_t2_plus_t3': True,
                          'all_t2_non_knowledge_24_files_inherited_exactly': True,
                          'authority_contract_and_plan_unchanged': True,
                          'no_unexpected_source_files_in_frozen_snapshots': True,
                          'no_git_object_written': True, 'author_worktree_read': False},
        'authority_hashes': authority_hashes, 'inheritance_17': inheritance,
        'main_sync_preparation': {'actual_main': MAIN, 'actual_main_tree': git('rev-parse', MAIN + '^{tree}').decode().strip(),
                                  'merge_base': merge_base, 'delta_files': main_delta_records,
                                  'main_side_product_test_delta': [], 'sync_performed': False,
                                  'proposed_merged_knowledge': proposed_knowledge},
        'knowledge_exception': {'t2_sha256': t2_hashes[KN], 't3_sha256': t3_hashes[KN],
                                'whole_file_bytes_equal': False,
                                'all_t2_lines_preserved_with_only_t3_insertions': True,
                                'insertions': kn_changes,
                                'final_main_and_candidate_fact_merge': 'TMP_PROPOSAL_VERIFIED; APPLICATION_PENDING'},
        'execution': {'product_imports': 0, 'tests': 0, 'full_suites': 0, 'lock_checks': 0, 'ruff_checks': 0,
                      'independent_probe_reruns': 0, 'author_tree_writes': 0, 'checkout_merge_commit_push': 0},
        'pending': ['T3 independent behavioral verdict and exact report binding',
                    'parent integration of actual main0df and factual KNOWLEDGE merge',
                    'parent final combined freeze and one centralized full/lock/ruff with raw originals',
                    'formal combined commit/blob/mode and gate-result binding',
                    'current implementation PR four required native CI checks and final merge verification'],
        'not_claimed': ['T3 behavioral approval', 'integrated local gates pass', 'new combined commit approval',
                        'new implementation PR/native CI pass', 'release or device support']})

    checklist = '''# 最终组合验收准备（PREPARATION_ONLY）

本记录只核冻结来源与继承，不是 T3 或最终组合通过记录。本轮未执行产品导入、测试、探针、full、lock 或 ruff；未读写作者工作树，未 checkout、merge、commit 或 push。

- [x] 基础输入为完整 Git585；T2 清单 dddec59d…、T3 清单 79f5287d… 均逐字节绑定。
- [x] Git585 441 项 → T2 463 项 → T3 485 项；25/26 项 overlay 只有知识库重叠，合计50个路径；267个非 docs 对象已列明源、SHA256、Git blob 和预期 mode。
- [x] T1 已审9项与恢复 fixture 共10项在 c145、585、T2、T3 中精确继承；T2四项、T3三项产品/测试来自相应冻结原件。
- [x] 固定契约 c62dba28…b8584 与计划 464849b2…e875 未变化。
- [x] main0df 相对共同祖先9129095仅知识库与三份PR134 CI文档变化，无产品/测试变化。
- [x] T2其余24项在T3中完全继承；T3知识库只在两个位置插入四行，全部T2行保留，但整文件hash不同。
- [x] 父会话/tmp知识库合并方案d7426e9d…971e仅插入main的两段原文，全部T3行保留；尚未应用到作者树。
- [ ] 接收 T3 独立第二读者的行为结论、完整输入/报告hash、零未决及其范围；作者本地结果不能代替。
- [ ] 父会话同步实际 main0df，仅知识库按双方事实合并；三份main证据按精确对象继承。最终事实/复审归档可能增加docs文件，需显式登记，不能将暂定488项当最终固定总数。
- [ ] 冻结最终组合全部跟踪对象；核267个非docs预期对象（若有实质变化重新评审），记录完整before清单与命令。
- [ ] 父会话集中一次 full/lock/ruff；绑定真实命令、exit、完整原始日志与SHA256、摘要及skip原因；after清单必须与before一致。本轮不重跑。
- [ ] 核changed files无占位、伪测试或新增跳过；检查契约/计划不漂移，归档当前独立证据，知识库§2/§8准确描述已验与待验。
- [ ] 正式提交后核完整SHA、parent、tree、每项blob/mode与冻结原件及三项本地门禁一致；提交后实质变化另审。
- [ ] 新实现PR按其当前完整SHA核四required原生CI及实际checkout/tree；旧main0df或T1的绿色不转移。通过前不宣称可合并或已交付。

后续正式绑定等待父会话提供最终冻结与门禁原件后开展。本准备阶段无行为裁决，所有pending保留在source-preparation.json。
'''
    (OUT / 'acceptance-checklist.md').write_text(checklist)
    names = ['prepare-source-binding.py', 'source-object-map.json', 'source-preparation.json', 'acceptance-checklist.md']
    write_json('preparation-sha256.json', {'stage': 'PREPARATION_ONLY', 'files': {
        name: {'sha256': sha((OUT / name).read_bytes()), 'bytes': (OUT / name).stat().st_size} for name in names}})
    print(json.dumps({'verdict': 'PREPARATION_ONLY', 'counts': {'base': len(base_tree), 't2': len(t2_hashes),
                      't3': len(t3_hashes), 'non_docs': len(non_docs)}, 'output': str(OUT),
                      'index_sha256': sha((OUT / 'preparation-sha256.json').read_bytes())}, ensure_ascii=False))


if __name__ == '__main__':
    main()
